import datetime
import html
import re
import textwrap

import streamlit as st

from ui.athlete_selection import render_athlete_selector

from core.capability import build_capability
from core.adaptive_coach_live import build_live_coach_decision
from core.adaptive_weekly_plan import build_adaptive_weekly_plan
from core.actionable_coaching import ActionableRecommendation
from core.coach_brain import CoachBrain
from core.coach_consensus import build_coach_consensus
from core.coaching import (
    METRES_PER_MILE,
    RunProfile,
    best_easy_run,
    build_baseline,
    equivalent_performance,
    seconds_to_pace,
)
from core.database import (
    get_active_goal,
    get_connection,
    get_effective_athlete_thresholds,
)
from core.evidence import EvidenceStatus
from core.environment_forecast import build_environment_forecast
from core.environment_profile import build_personal_environment_profile
from core.easy_run_coach import build_easy_run_coach
from core.evidence_engine import build_athlete_evidence_profile
from core.performance_dna import build_performance_dna
from core.performance_recognition import (
    build_recognition_index,
    recognition_key,
)
from core.training_blueprint import build_training_blueprint


SPORT_MAP = {
    "965611": ("Running", "Run"),
    "965617": ("Walking", "Walk"),
    "965613": ("Cycling", "Ride"),
    "965619": ("Indoor Cycling", "Indoor Ride"),
    "965612": ("Swimming", "Swim"),
    "965614": ("Strength / Mobility", "Strength"),
    "965615": ("Strength", "Strength"),
    "965616": ("Other / Gym", "Training"),
    "965630": ("Yoga / Stretching", "Yoga"),
    "965632": ("Hiking", "Hike"),
    "965621": ("Mountain / Gravel Bike", "Ride"),
    "1742104": ("Golf", "Golf"),
    "1637482": ("Pilates", "Pilates"),
}


def format_pace_value(seconds_per_km):
    if seconds_per_km is None:
        return "—"

    minutes = int(seconds_per_km // 60)
    seconds = int(round(seconds_per_km % 60))

    if seconds == 60:
        minutes += 1
        seconds = 0

    return f"{minutes}:{seconds:02d}/km"


def athlete_full_name(first_name, last_name):
    return f"{first_name or ''} {last_name or ''}".strip()


def update_selected_athlete():
    """Persist the athlete selected in the visible page widget."""
    st.session_state.selected_athlete_name = (
        st.session_state.athlete_selector_widget
    )


def initialise_selected_athlete(athlete_names):
    """Set a valid shared athlete selection for all pages."""
    if (
        "selected_athlete_name" not in st.session_state
        or st.session_state.selected_athlete_name not in athlete_names
    ):
        st.session_state.selected_athlete_name = athlete_names[0]

    st.session_state.athlete_selector_widget = (
        st.session_state.selected_athlete_name
    )


def get_athletes():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, first_name, last_name
        FROM athletes
        ORDER BY first_name, last_name
        """
    )
    athletes = cursor.fetchall()
    conn.close()
    return athletes


def get_athlete_thresholds(athlete_id):
    return get_effective_athlete_thresholds(athlete_id)

def get_recent_activity_timing_context(athlete_id):
    """Load display context not currently carried by RunProfile."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT
            activity_date,
            title,
            distance_m,
            moving_time_s,
            elapsed_time_s,
            wind_speed,
            route_name
        FROM activities
        WHERE athlete_id = ?
        ORDER BY activity_datetime DESC
        """,
        (athlete_id,),
    )
    rows = cursor.fetchall()
    conn.close()

    context = {}
    for (
        activity_date,
        title,
        distance_value,
        moving_time_s,
        elapsed_time_s,
        wind_speed,
        route_name,
    ) in rows:
        try:
            distance_value = float(distance_value or 0.0)
        except (TypeError, ValueError):
            distance_value = 0.0

        distance_km = (
            distance_value / 1000.0
            if distance_value > 250.0
            else distance_value
        )
        key = "|".join(
            (
                str(activity_date or ""),
                str(title or ""),
                f"{distance_km:.3f}",
            )
        )

        try:
            moving = float(moving_time_s)
        except (TypeError, ValueError):
            moving = None
        try:
            elapsed = float(elapsed_time_s)
        except (TypeError, ValueError):
            elapsed = None
        try:
            wind = float(wind_speed)
        except (TypeError, ValueError):
            wind = None

        if moving and elapsed and moving > 0 and elapsed > 0:
            moving_percent = min(max((moving / elapsed) * 100.0, 0.0), 100.0)
        else:
            moving_percent = None

        context[key] = {
            "moving_time_s": moving,
            "elapsed_time_s": elapsed,
            "moving_percent": moving_percent,
            "wind_speed": wind,
            "route_name": route_name,
        }
    return context

def get_lifetime_summary(athlete_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT
            COUNT(*),
            COALESCE(SUM(distance_m), 0),
            COALESCE(SUM(moving_time_s), 0),
            COALESCE(SUM(elevation_up_m), 0)
        FROM activities
        WHERE athlete_id = ?
        """,
        (athlete_id,),
    )
    row = cursor.fetchone()
    conn.close()
    return row


def get_year_summary(athlete_id, year):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT
            COUNT(*),
            COALESCE(SUM(distance_m), 0),
            COALESCE(SUM(moving_time_s), 0),
            COALESCE(SUM(elevation_up_m), 0)
        FROM activities
        WHERE athlete_id = ?
          AND substr(activity_date, 1, 4) = ?
        """,
        (athlete_id, str(year)),
    )
    row = cursor.fetchone()
    conn.close()
    return row


def get_recent_weekly_average(athlete_id, weeks=26):
    """
    Return trailing average weekly distance ending on the latest imported run.
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT MAX(date(activity_date))
        FROM activities
        WHERE athlete_id = ?
          AND activity_date IS NOT NULL
        """,
        (athlete_id,),
    )
    row = cursor.fetchone()
    latest_date_text = row[0] if row else None

    if not latest_date_text:
        conn.close()
        return 0.0, None

    latest_date = datetime.date.fromisoformat(latest_date_text)
    start_date = latest_date - datetime.timedelta(weeks=weeks)

    cursor.execute(
        """
        SELECT COALESCE(SUM(distance_m), 0)
        FROM activities
        WHERE athlete_id = ?
          AND date(activity_date) > ?
          AND date(activity_date) <= ?
        """,
        (
            athlete_id,
            start_date.isoformat(),
            latest_date.isoformat(),
        ),
    )
    total_distance_km = cursor.fetchone()[0] or 0
    conn.close()

    return total_distance_km / weeks, latest_date


def get_run_profiles(athlete_id, athlete_thresholds):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT
            activity_date,
            title,
            distance_m,
            moving_time_s,
            avg_hr,
            max_hr,
            sport_id,
            elevation_up_m,
            temperature_c,
            humidity
        FROM activities
        WHERE athlete_id = ?
        ORDER BY activity_datetime DESC
        """,
        (athlete_id,),
    )

    rows = cursor.fetchall()
    conn.close()

    return [
        RunProfile(
            athlete_id=athlete_id,
            activity_date=activity_date,
            title=title,
            distance_km=distance_km,
            moving_time_seconds=moving_time_s,
            avg_hr=avg_hr,
            run_max_hr=run_max_hr,
            sport_id=sport_id,
            elevation_m=elevation_m,
            temperature_c=temperature_c,
            humidity=humidity,
            lt1_hr=athlete_thresholds["lt1_hr"],
            lt2_hr=athlete_thresholds["lt2_hr"],
            athlete_max_hr=athlete_thresholds["athlete_max_hr"],
        )
        for (
            activity_date,
            title,
            distance_km,
            moving_time_s,
            avg_hr,
            run_max_hr,
            sport_id,
            elevation_m,
            temperature_c,
            humidity,
        ) in rows
    ]


def safe_text(value):
    return html.escape(str(value or ""))


def render_html(markup):
    cleaned_markup = textwrap.dedent(markup).strip()
    st.html(cleaned_markup)


def format_date(date_text):
    try:
        parsed_date = datetime.date.fromisoformat(date_text)
        return parsed_date.strftime("%d %b")
    except (TypeError, ValueError):
        return date_text or "Unknown"


def format_goal_date(date_text):
    if not date_text:
        return "No target date"

    try:
        parsed_date = datetime.date.fromisoformat(date_text)
        return parsed_date.strftime("%d %b %Y")
    except (TypeError, ValueError):
        return date_text


def format_clock(seconds):
    if seconds is None:
        return "--"

    seconds = int(round(seconds))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    remaining_seconds = seconds % 60

    if hours:
        return f"{hours}:{minutes:02d}:{remaining_seconds:02d}"

    return f"{minutes}:{remaining_seconds:02d}"


def format_duration(seconds):
    if seconds is None:
        return "—"

    total = int(round(seconds))
    hours = total // 3600
    minutes = (total % 3600) // 60
    remaining = total % 60

    if hours:
        return f"{hours}:{minutes:02d}:{remaining:02d}"

    return f"{minutes}:{remaining:02d}"


def format_distance_miles(distance_km):
    miles = (distance_km or 0) / (METRES_PER_MILE / 1000)
    return f"{miles:.1f} mi"


def format_pace_per_mile(seconds_per_km):
    if not seconds_per_km:
        return "--"

    seconds_per_mile = seconds_per_km * (METRES_PER_MILE / 1000)
    return f"{seconds_to_pace(seconds_per_mile)}/mi"


def format_hours(seconds):
    return f"{(seconds or 0) / 3600:,.0f} hrs"


def get_sport_name(sport_id):
    return SPORT_MAP.get(str(sport_id or ""), ("Activity", "Activity"))


def evidence_strength(confidence):
    if confidence >= 0.85:
        return "Very strong"
    if confidence >= 0.70:
        return "Strong"
    if confidence >= 0.50:
        return "Developing"
    if confidence > 0:
        return "Limited"
    return "Unavailable"


def status_label(status):
    if status == EvidenceStatus.AVAILABLE:
        return "Available"
    if status == EvidenceStatus.BUILDING:
        return "Building"
    return "Unavailable"



def greeting_for_current_time(now=None):
    """Return a local, time-aware greeting."""
    current = now or datetime.datetime.now()
    hour = current.hour

    if 5 <= hour < 12:
        return "Good morning"
    if 12 <= hour < 17:
        return "Good afternoon"
    if 17 <= hour < 22:
        return "Good evening"

    return "Hello"

def render_header(first_name, goal):
    if goal is None:
        intro = (
            "Choose an objective to connect your training history to "
            "personalised progress and future race prediction."
        )
    else:
        intro = (
            f"Your active goal is "
            f"<strong>{safe_text(goal['goal_name'])}</strong>. "
            "The Coach Brain is now inspecting the evidence behind it."
        )

    render_html(
        f"""
        <div class="pp-page-header">
            <div class="pp-page-eyebrow">Coach</div>
            <div class="pp-page-title">
                {safe_text(greeting_for_current_time())}, {safe_text(first_name)}.
            </div>
            <div class="pp-page-intro">{intro}</div>
        </div>
        """
    )



def coach_status_icon(status):
    return {
        "strong": "🟢",
        "steady": "🟡",
        "limited": "🟠",
        "building": "⚪",
    }.get(status, "⚪")


def render_coaching_meeting(
    performance_dna,
    prediction,
    coach_consensus,
):
    """Render the shared Personal Performance DNA view."""
    render_html(
        f"""
        <div class="pp-card pp-card-hero">
            <div class="pp-card-label">Personal Performance DNA</div>
            <div class="pp-card-title">
                {safe_text(performance_dna.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(performance_dna.summary)}
            </div>

            <div style="
                display:grid;
                grid-template-columns:repeat(3, minmax(0, 1fr));
                gap:0.8rem;
                margin-top:1rem;
                padding-top:0.9rem;
                border-top:1px solid var(--pp-border);
            ">
                <div>
                    <div class="pp-stat-label">Coaches connected</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {performance_dna.available_coach_count}/
                        {performance_dna.total_coach_count}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Team confidence</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {performance_dna.overall_confidence:.0%}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Consensus</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(
                            performance_dna.consensus_status
                            .replace("_", " ")
                            .title()
                        )}
                    </div>
                </div>
            </div>
        </div>
        """
    )

    if any(performance_dna.system_scores.values()):
        st.markdown("### Athlete Performance DNA")

        system_labels = {
            "threshold": "❤️ Threshold",
            "speed": "⚡ Speed / VO₂",
            "endurance": "🧱 Endurance",
            "aerobic": "😊 Aerobic",
        }

        st.caption(
            f"{performance_dna.athlete_profile_label} · "
            f"aggregated confidence "
            f"{performance_dna.athlete_dna_confidence:.0%}. "
            "Scores combine specialist coaches, long-term history and "
            "Workout DNA, so one session cannot redefine the athlete."
        )

        system_columns = st.columns(4)

        for column, system_key in zip(
            system_columns,
            ("threshold", "speed", "endurance", "aerobic"),
        ):
            score = performance_dna.system_scores.get(
                system_key,
                0,
            )

            with column:
                st.metric(
                    system_labels[system_key],
                    f"{score:.0f}/100",
                )
                st.progress(
                    min(max(score / 100.0, 0.0), 1.0)
                )
                system_confidence = (
                    performance_dna.system_confidence.get(
                        system_key,
                        0,
                    )
                )
                st.caption(
                    f"Evidence confidence {system_confidence:.0%}"
                )

    st.markdown("### Today's coaching meeting")

    for verdict in performance_dna.verdicts:
        left, middle, right = st.columns([0.48, 0.27, 0.25])

        with left:
            st.markdown(
                f"{coach_status_icon(verdict.status)} "
                f"**{verdict.icon} {verdict.title}**"
            )
            st.caption(verdict.evidence_summary)

        with middle:
            st.write(verdict.verdict)
            if verdict.available:
                st.caption(f"Confidence {verdict.confidence:.0%}")
            else:
                st.caption("No invented opinion")

        with right:
            if verdict.predicted_seconds is not None:
                st.metric(
                    "Goal view",
                    format_clock(verdict.predicted_seconds),
                )
            elif verdict.available:
                st.write(verdict.signal)
            else:
                st.write("Building")

    st.markdown("### 🎯 Goal Coach consensus")

    if prediction.available:
        consensus_columns = st.columns(3)
        consensus_columns[0].metric(
            "Consensus capability",
            format_clock(prediction.predicted_seconds),
        )
        consensus_columns[1].metric(
            "Consensus confidence",
            f"{coach_consensus.confidence:.0%}",
        )
        consensus_columns[2].metric(
            "Lead opinion",
            coach_consensus.lead_coach or "Building",
        )

        if coach_consensus.status == "aligned":
            st.success(coach_consensus.headline)
        elif coach_consensus.status == "mixed":
            st.warning(coach_consensus.headline)
        else:
            st.info(coach_consensus.headline)

        if coach_consensus.summary:
            st.write(coach_consensus.summary)

        if coach_consensus.positions:
            with st.expander("How the coaches reached consensus"):
                for position in coach_consensus.positions:
                    difference = position.difference_seconds
                    if abs(difference) < 0.5:
                        difference_text = "matches consensus"
                    elif difference < 0:
                        difference_text = (
                            f"{abs(difference):.0f}s faster than consensus"
                        )
                    else:
                        difference_text = (
                            f"{difference:.0f}s slower than consensus"
                        )

                    st.write(
                        f"**{position.title}: "
                        f"{format_clock(position.predicted_seconds)}** · "
                        f"{difference_text} · "
                        f"{position.confidence:.0%} confidence"
                    )

                for note in coach_consensus.notes:
                    st.caption("Consensus note: " + note)
    else:
        st.info(
            "The Goal Coach is waiting for enough specialist evidence "
            "before giving a consensus capability."
        )

    if coach_consensus.strongest_system:
        label_map = {
            "threshold": "Threshold",
            "speed": "Speed / VO₂",
            "endurance": "Endurance",
            "aerobic": "Aerobic",
        }
        strongest_label = label_map[
            coach_consensus.strongest_system
        ]
        priority_label = (
            label_map[coach_consensus.development_priority]
            if coach_consensus.development_priority
            else "Still learning"
        )

        st.caption(
            f"Current athlete strength: {strongest_label}. "
            f"Current development priority: {priority_label}. "
            "A training recommendation will wait for Readiness Coach "
            "rather than being invented from profile scores alone."
        )


def render_daily_coach(
    athlete_id,
    first_name,
    goal,
    prediction,
    brain_brief,
    evidence_bundle,
    latest_activity_date,
):
    goal_name = goal["goal_name"] if goal else "No active goal"
    capability = (
        format_clock(prediction.predicted_seconds)
        if prediction.available
        else "Not available"
    )
    strength = evidence_strength(evidence_bundle.confidence)
    data_date = (
        latest_activity_date.strftime("%d %b %Y")
        if latest_activity_date is not None
        else "No activity date"
    )

    live_decision = build_live_coach_decision(
        athlete_id
    )

    recommendation_title = (
        live_decision.immediate_label
        if live_decision is not None
        else "Building recommendation"
    )
    recommendation_detail = (
        (
            f"{live_decision.immediate_timing} · "
            f"{live_decision.immediate_detail}"
        )
        if live_decision is not None
        else "Adaptive Coach needs more evidence before prescribing the next run."
    )

    render_html(
        f"""
        <div class="pp-card pp-card-hero pp-card-accent">
            <div class="pp-card-label">Daily coach</div>
            <div class="pp-card-title" style="font-size:1.55rem;">
                {safe_text(brain_brief.headline)}
            </div>
            <div class="pp-card-copy" style="font-size:1rem;">
                {safe_text(brain_brief.summary)}
            </div>

            <div style="
                display:grid;
                grid-template-columns:repeat(3, minmax(0, 1fr));
                gap:1rem;
                margin-top:1.2rem;
                padding-top:1rem;
                border-top:1px solid var(--pp-border);
            ">
                <div>
                    <div class="pp-stat-label">Goal</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(goal_name)}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Current capability</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(capability)}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Evidence strength</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(strength)}
                    </div>
                </div>
            </div>

            <div style="
                margin-top:1rem;
                padding-top:0.9rem;
                border-top:1px solid var(--pp-border);
            ">
                <div class="pp-card-label">Next run</div>
                <div class="pp-card-title" style="font-size:1rem;">
                    {safe_text(recommendation_title)}
                </div>
                <div class="pp-small-meta">
                    {safe_text(recommendation_detail)}
                </div>
            </div>

            <div class="pp-small-meta" style="margin-top:0.9rem;">
                Evidence updated through {safe_text(data_date)}.
            </div>
        </div>
        """
    )

    with st.expander("Why is the Coach saying this?"):
        st.write(f"**Goal:** {goal_name}")
        st.write(
            f"**Prediction:** "
            f"{capability if prediction.available else prediction.explanation}"
        )
        st.write(
            f"**Evidence strength:** {strength} "
            f"({evidence_bundle.confidence:.0%})"
        )

        if live_decision is not None:
            st.write(
                f"**Next run:** "
                f"{live_decision.immediate_label} · "
                f"{live_decision.immediate_timing}"
            )
            st.caption(live_decision.immediate_detail)

            if live_decision.key_label:
                st.write(
                    f"**Next key workout:** "
                    f"{live_decision.key_label}"
                )
                if live_decision.key_prescription:
                    st.caption(
                        live_decision.key_prescription
                    )

        for item in evidence_bundle.items:
            st.markdown(f"**{item.title}**")
            st.write(item.summary)

            limitations = item.metadata.get("limitations", [])
            if limitations:
                st.caption("Limitations")
                for limitation in limitations:
                    st.write(f"• {limitation}")




def goal_distance_km(goal):
    """Resolve a goal distance from whichever goal field is available."""
    if goal is None:
        return None

    for key in (
        "distance_km",
        "goal_distance_km",
        "target_distance_km",
    ):
        value = goal.get(key)

        if value is not None:
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue

            if value > 0:
                return value

    goal_name = str(goal.get("goal_name") or "").lower()

    if "marathon" in goal_name and "half" not in goal_name:
        return 42.195
    if "half" in goal_name:
        return 21.0975
    if "10k" in goal_name or "10 km" in goal_name:
        return 10.0
    if "5k" in goal_name or "5 km" in goal_name:
        return 5.0

    return None





def format_rep_distance(distance_km):
    if distance_km is None:
        return "—"

    if abs(distance_km - 1.609344) <= 0.08:
        return "1 mile"

    if distance_km >= 1.0:
        return f"{distance_km:.2f} km"

    metres = int(round(distance_km * 1000 / 25) * 25)
    return f"{metres}m"


def format_recovery(seconds):
    if seconds is None:
        return "Still learning"

    seconds = int(round(seconds))

    if seconds >= 120 and seconds % 60 == 0:
        return f"{seconds // 60} min"

    return f"{seconds} sec"



def render_training_blueprint(blueprint, thresholds):
    st.markdown("## 🧬 Coach Blueprints")

    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Coach Blueprints</div>
            <div class="pp-card-title">
                {safe_text(blueprint.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(blueprint.summary)}
            </div>
        </div>
        """
    )

    threshold_source = thresholds.get(
        "source",
        "Calculated profile",
    )
    st.caption(
        f"Physiological boundary source: {threshold_source}. "
        "Each coach learns what your strongest historical sessions "
        "usually look like."
    )

    available = [
        category
        for category in blueprint.categories
        if category.sample_size >= 4
    ]

    if not available:
        st.info(
            "Each coach needs at least four comparable sessions before "
            "showing a personal blueprint."
        )
        return

    coach_order = (
        ("Easy Coach", "😊"),
        ("Threshold Coach", "❤️"),
        ("Speed Coach", "⚡"),
    )

    for coach_name, coach_icon in coach_order:
        categories = [
            category
            for category in available
            if category.coach == coach_name
        ]

        if not categories:
            continue

        st.markdown(
            f"### {coach_icon} {coach_name}"
        )
        st.caption(
            "This is what your strongest historical sessions "
            "in this area usually look like."
        )

        columns = st.columns(
            min(len(categories), 3)
        )

        for column, category in zip(
            columns,
            categories,
        ):
            with column:
                st.markdown(
                    f"**{category.label}**"
                )

                if (
                    category.coach == "Speed Coach"
                    and category.rep_metric_sample_size > 0
                ):
                    metric_columns = st.columns(2)
                    metric_columns[0].metric(
                        "Typical rep",
                        format_rep_distance(
                            category.rep_distance_typical_km
                        ),
                    )
                    metric_columns[1].metric(
                        "Rep pace",
                        (
                            format_pace_value(
                                category.rep_pace_typical_s_per_km
                            )
                            if category.rep_pace_typical_s_per_km is not None
                            else "Still learning"
                        ),
                    )

                    if (
                        category.rep_pace_low_s_per_km is not None
                        and category.rep_pace_high_s_per_km is not None
                    ):
                        faster = min(
                            category.rep_pace_low_s_per_km,
                            category.rep_pace_high_s_per_km,
                        )
                        slower = max(
                            category.rep_pace_low_s_per_km,
                            category.rep_pace_high_s_per_km,
                        )
                        st.caption(
                            "Strong-session rep pace range: "
                            f"{format_pace_value(faster)}–"
                            f"{format_pace_value(slower)}"
                        )

                    detail_columns = st.columns(2)
                    detail_columns[0].metric(
                        "Typical recovery",
                        format_recovery(
                            category.recovery_typical_s
                        ),
                    )
                    detail_columns[1].metric(
                        "Current reps",
                        (
                            f"{category.recent_rep_count_typical:.0f}"
                            if category.recent_rep_count_typical is not None
                            else "—"
                        ),
                    )

                    if category.recent_quality_volume_typical_km is not None:
                        st.caption(
                            "Current quality volume: "
                            f"{category.recent_quality_volume_typical_km:.1f} km"
                        )

                    if (
                        category.historical_rep_count_typical is not None
                        and category.recent_rep_count_typical is not None
                        and category.historical_profile_sample_size > 1
                    ):
                        history_text = (
                            f"Historical {category.comparable_distance_label or 'comparable'} "
                            f"profile: {category.historical_rep_count_typical:.0f} reps"
                        )
                        if category.historical_quality_volume_typical_km is not None:
                            history_text += (
                                " · "
                                f"{category.historical_quality_volume_typical_km:.1f} km quality"
                            )
                        st.caption(history_text)

                    st.caption(
                        f"Compared with {category.current_profile_sample_size} recent "
                        f"{category.comparable_distance_label or 'similar'} workout blocks. "
                        "Heart rate is secondary context for short repetitions."
                    )
                else:
                    if (
                        category.hr_low is not None
                        and category.hr_high is not None
                    ):
                        st.metric(
                            "HR sweet spot",
                            f"{category.hr_low}–{category.hr_high} bpm",
                        )
                    else:
                        st.metric("HR sweet spot", "Still learning")

                    if (
                        category.show_pace
                        and category.pace_low_s_per_km is not None
                        and category.pace_high_s_per_km is not None
                    ):
                        faster = min(
                            category.pace_low_s_per_km,
                            category.pace_high_s_per_km,
                        )
                        slower = max(
                            category.pace_low_s_per_km,
                            category.pace_high_s_per_km,
                        )
                        st.caption(
                            "Adjusted pace sweet spot: "
                            f"{format_pace_per_mile(faster)}–"
                            f"{format_pace_per_mile(slower)}"
                        )
                    elif not category.show_pace:
                        st.caption(
                            "Activity-average pace is hidden because warm-up, "
                            "recoveries and cool-down distort it."
                        )

                    if category.typical_distance_km is not None:
                        distance_miles = (
                            category.typical_distance_km
                            / (METRES_PER_MILE / 1000)
                        )
                        st.caption(
                            "Usually works well around "
                            f"{distance_miles:.1f} miles"
                        )

                st.caption(
                    f"{category.sample_size} comparable sessions · "
                    f"{confidence_label(category.confidence)}"
                )

    with st.expander(
        "How Coach Blueprints are calculated"
    ):
        st.write(
            "Easy Coach ranks genuine running activities by "
            "condition-adjusted speed per heartbeat, then studies the "
            "best 30% of comparable runs. Threshold and Speed coaches "
            "use trusted Workout DNA. Speed Coach prioritises rep pace, "
            "rep length, recovery and quality volume; HR is secondary for "
            "short repetitions because it lags the effort."
        )

        for limitation in blueprint.limitations:
            st.write(f"• {limitation}")

def evidence_status_icon(status):
    return {
        "available": "🟢",
        "developing": "🟡",
        "limited": "🟠",
        "unavailable": "⚪",
    }.get(status, "⚪")


def render_evidence_engine(profile):
    st.markdown("## 📚 Coaching Evidence")

    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Evidence Engine</div>
            <div class="pp-card-title">
                {safe_text(profile.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(profile.summary)}
            </div>
        </div>
        """
    )

    columns = st.columns(4)
    columns[0].metric(
        "Runs inspected",
        f"{profile.run_count:,}",
    )
    columns[1].metric(
        "Ready metrics",
        profile.available_metric_count,
    )
    columns[2].metric(
        "Developing",
        profile.developing_metric_count,
    )
    columns[3].metric(
        "Need more data",
        profile.unavailable_metric_count,
    )

    ready = [
        metric
        for metric in profile.metrics
        if metric.status == "available"
    ]
    developing = [
        metric
        for metric in profile.metrics
        if metric.status in {"developing", "limited"}
    ]
    unavailable = [
        metric
        for metric in profile.metrics
        if metric.status == "unavailable"
    ]

    if ready:
        st.markdown("### Evidence ready for coaching")
        ready_columns = st.columns(3)

        for index, metric in enumerate(ready):
            with ready_columns[index % 3]:
                st.markdown(
                    f"{evidence_status_icon(metric.status)} "
                    f"**{metric.label}**"
                )
                st.caption(
                    f"{metric.available_count:,} activities · "
                    f"{metric.coverage:.0%} coverage"
                )
                st.write(metric.coaching_use)

    with st.expander("Full evidence audit"):
        for heading, group in (
            ("Ready", ready),
            ("Developing", developing),
            ("Requires more data", unavailable),
        ):
            if not group:
                continue

            st.markdown(f"**{heading}**")

            for metric in group:
                st.write(
                    f"{evidence_status_icon(metric.status)} "
                    f"**{metric.label}** — "
                    f"{metric.available_count:,}/"
                    f"{metric.activity_count:,} activities"
                )
                st.caption(
                    f"Source: {metric.source}. {metric.note}"
                )

        st.info(
            "Actionable Coaching will only use metrics marked Ready, or "
            "Developing metrics with an explicit lower-confidence label."
        )

def render_easy_run_coach(result):
    st.markdown("## 😊 Easy Run Coach")

    if not result.available or result.latest is None:
        st.info(result.summary)
        return

    latest = result.latest
    dimensions = latest.dimensions

    render_html(
        f"""
        <div class="pp-card pp-card-hero">
            <div class="pp-card-label">Easy Run Coach V2</div>
            <div class="pp-card-title">
                {safe_text(result.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(result.summary)}
            </div>
        </div>
        """
    )

    top_columns = st.columns(4)
    top_columns[0].metric(
        "Training purpose",
        latest.run_type,
    )
    top_columns[1].metric(
        "Verdict",
        latest.verdict,
    )
    top_columns[2].metric(
        "Historical rank",
        f"{latest.rank} of {latest.comparison_count}",
    )
    top_columns[3].metric(
        "Evidence strength",
        confidence_label(result.confidence),
    )

    if latest.secondary_effect:
        st.caption(
            f"Secondary effect: {latest.secondary_effect}"
        )

    st.markdown("### Easy-run quality")

    dimension_data = (
        ("❤️ Aerobic control", dimensions.aerobic_control),
        ("⚙️ Efficiency", dimensions.efficiency),
        ("📊 Effort stability", dimensions.effort_stability),
        ("🔋 Recovery value", dimensions.recovery_value),
        ("🎯 Execution", dimensions.execution),
    )

    dimension_columns = st.columns(5)

    for column, (label, score) in zip(
        dimension_columns,
        dimension_data,
    ):
        with column:
            st.metric(label, f"{score:.0f}/100")
            st.progress(
                min(max(score / 100.0, 0.0), 1.0)
            )

    st.caption(
        f"Latest suitable easy run: {latest.activity_date or 'Unknown date'} · "
        f"{latest.distance_km:.2f} km · "
        f"{format_pace_value(latest.actual_pace_s_per_km)} actual · "
        f"{format_pace_value(latest.equivalent_pace_s_per_km)} "
        "condition-adjusted · "
        f"{latest.avg_hr:.0f} bpm"
    )

    if latest.achievements:
        st.markdown("### Achievements")
        for achievement in latest.achievements:
            st.success(achievement)

    recommendation = result.actionable_recommendation

    st.markdown("### 🎯 Actionable coaching")

    if recommendation is not None and recommendation.available:
        render_html(
            f"""
            <div class="pp-card pp-card-accent">
                <div class="pp-card-label">
                    {safe_text(recommendation.impact_label)}
                </div>
                <div class="pp-card-title">
                    {safe_text(recommendation.headline)}
                </div>
                <div class="pp-card-copy">
                    {safe_text(recommendation.recommendation)}
                </div>
            </div>
            """
        )

        action_columns = st.columns(3)
        action_columns[0].metric(
            recommendation.category,
            f"{recommendation.current_score:.0f} → "
            f"{recommendation.potential_score:.0f}",
        )
        action_columns[1].metric(
            "Overall quality",
            f"{recommendation.overall_current:.0f} → "
            f"{recommendation.overall_potential:.0f}",
        )
        action_columns[2].metric(
            "Recommendation confidence",
            recommendation.confidence_label,
        )

        st.caption(recommendation.reason)

        with st.expander("Evidence behind this recommendation"):
            for evidence_item in recommendation.evidence:
                st.write(f"✓ {evidence_item}")

            for limitation in recommendation.limitations:
                st.write(f"• {limitation}")
    else:
        st.info(
            "Easy Run Coach is still gathering enough evidence to make a "
            "specific recommendation."
        )

    trend_columns = st.columns(2)
    trend_columns[0].metric(
        "Aerobic trend",
        result.trend_label,
        (
            f"{result.trend_percent:+.1f}%"
            if result.trend_percent is not None
            else None
        ),
    )
    trend_columns[1].metric(
        "Overall easy-run quality",
        f"{dimensions.overall:.0f}/100",
    )

    with st.expander("Why does Easy Run Coach believe this?"):
        for reason in latest.reasons:
            st.write(f"✓ {reason}")

        if result.strengths:
            st.markdown("**Evidence base**")
            for strength in result.strengths:
                st.write(f"✓ {strength}")

        st.markdown("**Limitations**")
        for limitation in result.limitations:
            st.write(f"• {limitation}")

def render_capability_card(capability):
    st.markdown("## Current capability")

    if not capability.available:
        st.info(capability.explanation)
        return

    render_html(
        f"""
        <div class="pp-card pp-card-hero pp-card-accent">
            <div class="pp-card-label">Capability Engine</div>
            <div class="pp-card-title">
                {safe_text(capability.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(capability.explanation)}
            </div>
        </div>
        """
    )

    columns = st.columns(4)
    columns[0].metric(
        "Most likely",
        format_clock(capability.central_seconds),
    )
    columns[1].metric(
        "Likely range",
        (
            f"{format_clock(capability.low_seconds)}–"
            f"{format_clock(capability.high_seconds)}"
        ),
    )
    columns[2].metric(
        "Evidence strength",
        confidence_label(capability.confidence),
    )

    if capability.target_probability is not None:
        columns[3].metric(
            "Goal probability",
            f"{capability.target_probability:.0%}",
        )
    else:
        columns[3].metric(
            "Goal probability",
            "No timed target",
        )

    if capability.target_gap_seconds is not None:
        gap = capability.target_gap_seconds
        if abs(gap) < 0.5:
            gap_text = "Capability matches the target."
        elif gap < 0:
            gap_text = (
                f"Current capability is {abs(gap):.0f} seconds "
                "inside the target."
            )
        else:
            gap_text = (
                f"The target is {gap:.0f} seconds ahead of the "
                "central capability estimate."
            )
        st.caption(gap_text)

    with st.expander("Why this capability estimate?"):
        st.write(
            f"**Calculated confidence:** "
            f"{capability.confidence:.0%}"
        )

        for item in capability.evidence:
            st.write(f"✓ {item}")

        st.markdown("**Current interpretation**")
        st.write(capability.explanation)

        st.markdown("**Limitations**")
        for limitation in capability.limitations:
            st.write(f"• {limitation}")




def confidence_label(confidence):
    if confidence >= 0.85:
        return "Very strong evidence"
    if confidence >= 0.70:
        return "Strong evidence"
    if confidence >= 0.50:
        return "Moderate evidence"
    if confidence >= 0.25:
        return "Early evidence"
    return "Still learning"


def response_badge(multiplier, confidence):
    if confidence < 0.25:
        return "Still learning"

    difference = abs(multiplier - 1.0)

    if difference < 0.08:
        return "About average"

    if multiplier < 0.70:
        return "Exceptional"
    if multiplier < 0.88:
        return "Very good"
    if multiplier < 1.0:
        return "Better than average"
    if multiplier <= 1.15:
        return "Slightly more affected"
    if multiplier <= 1.35:
        return "More affected"
    return "Significantly more affected"


def environment_coaching_text(
    *,
    condition,
    multiplier,
    confidence,
):
    if confidence < 0.25:
        return (
            f"Performance Passport is still learning how {condition} "
            "affects you."
        )

    difference_percent = abs(multiplier - 1.0) * 100

    if difference_percent < 5:
        return (
            f"{condition.title()} appears to affect you about as much as "
            "the standard runner model expects."
        )

    if multiplier < 1.0:
        return (
            f"You appear to cope with {condition} around "
            f"{difference_percent:.0f}% better than the standard model."
        )

    return (
        f"{condition.title()} appears to affect you around "
        f"{difference_percent:.0f}% more than the standard model."
    )


def environment_sample_text(
    *,
    sample_size,
    confidence,
):
    if confidence < 0.25:
        return (
            f"{sample_size} comparable examples available · "
            "more evidence needed"
        )

    return (
        f"{sample_size} comparable examples · "
        f"{confidence_label(confidence)}"
    )

def render_personal_environment_profile(profile):
    st.markdown("### 🌍 Environmental profile")
    st.caption(
        "How your historical runs suggest you respond to heat, hills and "
        "trail compared with the standard forecast model."
    )

    conditions = (
        {
            "label": "🔥 Heat",
            "name": "heat",
            "multiplier": profile.heat_multiplier,
            "sample_size": profile.heat_sample_size,
            "confidence": profile.heat_confidence,
        },
        {
            "label": "⛰️ Hills",
            "name": "hills",
            "multiplier": profile.hill_multiplier,
            "sample_size": profile.hill_sample_size,
            "confidence": profile.hill_confidence,
        },
        {
            "label": "🌲 Trail",
            "name": "trail",
            "multiplier": profile.trail_multiplier,
            "sample_size": profile.trail_sample_size,
            "confidence": profile.trail_confidence,
        },
    )

    columns = st.columns(3)

    for column, condition in zip(columns, conditions):
        with column:
            st.markdown(f"**{condition['label']}**")
            badge = response_badge(
                condition["multiplier"],
                condition["confidence"],
            )
            st.markdown(f"### {badge}")
            st.write(
                environment_coaching_text(
                    condition=condition["name"],
                    multiplier=condition["multiplier"],
                    confidence=condition["confidence"],
                )
            )
            st.caption(
                environment_sample_text(
                    sample_size=condition["sample_size"],
                    confidence=condition["confidence"],
                )
            )

    with st.expander("Why does the coach believe this?"):
        st.write(
            "The engine compares pace relative to heart rate across "
            "similar historical runs. It keeps the calculations in the "
            "background and blends personal evidence conservatively with "
            "the standard forecast model."
        )

        for reason in profile.reasons:
            st.write(f"✓ {reason}")

        for limitation in profile.limitations:
            st.write(f"• {limitation}")

        st.caption(
            "Technical coefficients remain internal because they are model "
            "inputs, not useful coaching language."
        )

def render_environment_forecast(forecast):
    st.markdown("## Performance forecast")

    if not forecast.available:
        st.info(forecast.summary)
        return

    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Environment Engine</div>
            <div class="pp-card-title">
                {safe_text(forecast.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(forecast.summary)}
            </div>
        </div>
        """
    )

    scenario_columns = st.columns(3)

    for index, scenario in enumerate(forecast.scenarios):
        column = scenario_columns[index % 3]

        with column:
            st.markdown(f"**{scenario.label}**")
            st.metric(
                "Expected",
                format_clock(scenario.central_seconds),
            )
            st.caption(
                f"{format_clock(scenario.low_seconds)}–"
                f"{format_clock(scenario.high_seconds)} · "
                f"{scenario.adjustment_percent:+.1f}%"
            )

            if scenario.pace_seconds_per_km is not None:
                st.caption(
                    "Goal pace "
                    + format_pace_value(
                        scenario.pace_seconds_per_km
                    )
                )

            st.caption(scenario.description)
            st.caption(
                f"Forecast confidence {scenario.confidence:.0%}"
            )
            if scenario.personalised:
                st.caption(
                    "✓ Adjusted using your Environmental Profile"
                )
            else:
                st.caption(
                    "Standard model · personal evidence still building"
                )

    with st.expander("How environmental forecasts work"):
        st.write(
            "Capability represents the athlete's underlying fitness. "
            "The Environment Engine changes only the expected realised "
            "time under different conditions."
        )

        if "personal_environment_profile" in globals():
            pass

        for limitation in forecast.limitations:
            st.write(f"• {limitation}")

def render_goal_card(goal, prediction):
    if goal is None:
        render_html(
            """
            <div class="pp-card pp-card-hero pp-card-accent">
                <div class="pp-card-label">Goal progress</div>
                <div class="pp-card-title">No active goal</div>
                <div class="pp-card-copy">
                    Open the Goal page to choose the objective that matters
                    most to this athlete.
                </div>
                <div style="margin-top:0.8rem;">
                    <span class="pp-status pp-status-warning">
                        Goal not configured
                    </span>
                </div>
            </div>
            """
        )
        return

    target_text = (
        format_clock(goal["target_time_s"])
        if goal["target_time_s"] is not None
        else "Completion goal"
    )

    if prediction.available:
        prediction_text = format_clock(prediction.predicted_seconds)
        prediction_context = evidence_strength(prediction.confidence)
    else:
        prediction_text = "Not available"
        prediction_context = prediction.explanation

    race_text = goal["race_name"] or "No race selected"

    render_html(
        f"""
        <div class="pp-card pp-card-hero pp-card-accent">
            <div class="pp-card-label">Goal progress</div>
            <div class="pp-card-title">{safe_text(goal["goal_name"])}</div>

            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:1rem;
                margin-top:0.9rem;
            ">
                <div>
                    <div class="pp-small-meta">Target</div>
                    <div class="pp-large-value" style="margin-top:0.2rem;">
                        {safe_text(target_text)}
                    </div>
                </div>

                <div>
                    <div class="pp-small-meta">Prediction</div>
                    <div class="pp-card-title">{safe_text(prediction_text)}</div>
                    <div class="pp-small-meta">
                        {safe_text(prediction_context)}
                    </div>
                </div>
            </div>

            <div style="
                margin-top:0.9rem;
                padding-top:0.8rem;
                border-top:1px solid var(--pp-border);
                display:flex;
                justify-content:space-between;
                align-items:center;
                gap:1rem;
            ">
                <div class="pp-small-meta">
                    {safe_text(race_text)} ·
                    {safe_text(format_goal_date(goal["target_date"]))}
                </div>
                <div class="pp-status">Active goal</div>
            </div>
        </div>
        """
    )


def render_coach_brief(current_baseline, all_time_baseline, brain_brief):
    if current_baseline and all_time_baseline:
        pace_change_per_mile = (
            all_time_baseline.avg_pace_seconds_per_km
            - current_baseline.avg_pace_seconds_per_km
        ) * (METRES_PER_MILE / 1000)

        if pace_change_per_mile >= 2:
            baseline_message = (
                f"Your current easy-running baseline is approximately "
                f"{pace_change_per_mile:.0f} sec/mi faster than your "
                f"all-time baseline."
            )
        else:
            baseline_message = (
                "Your recent easy running is broadly consistent with your "
                "long-term baseline."
            )
    else:
        baseline_message = (
            "More comparable easy runs will strengthen your aerobic baseline."
        )

    render_html(
        f"""
        <div class="pp-card pp-card-hero">
            <div class="pp-card-label">Coach's brief</div>
            <div class="pp-card-title">
                {safe_text(brain_brief.headline)}
            </div>
            <div class="pp-card-copy">
                {safe_text(brain_brief.summary)}
            </div>

            <div style="
                margin-top:0.95rem;
                padding-top:0.85rem;
                border-top:1px solid var(--pp-border);
            ">
                <div class="pp-card-label">Aerobic context</div>
                <div class="pp-small-meta">
                    {safe_text(baseline_message)}
                </div>
            </div>
        </div>
        """
    )


def render_stat_card(label, value, context):
    render_html(
        f"""
        <div class="pp-stat-card">
            <div class="pp-stat-label">{safe_text(label)}</div>
            <div class="pp-stat-value">{safe_text(value)}</div>
            <div class="pp-stat-context">{safe_text(context)}</div>
        </div>
        """
    )


def render_latest_discovery(best_run):
    if best_run is None:
        title = "Your first discovery is taking shape."
        copy = (
            "Performance Passport needs more comparable easy runs before "
            "selecting your strongest aerobic performance."
        )
        confidence = "Building evidence"
    else:
        run = best_run.run
        performance = best_run.equivalent_performance

        title = "One of your strongest aerobic performances."
        copy = (
            f"{run.title or 'Easy Run'} on {format_date(run.activity_date)} "
            f"produced an equivalent pace of "
            f"{format_pace_per_mile(performance.equivalent_pace_seconds_per_km)}."
        )
        confidence = "High confidence"

    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Latest discovery</div>
            <div class="pp-card-title">{safe_text(title)}</div>
            <div class="pp-card-copy">{safe_text(copy)}</div>
            <div style="margin-top:0.8rem;">
                <span class="pp-status">{safe_text(confidence)}</span>
            </div>
        </div>
        """
    )


def render_evidence_card(item):
    status = status_label(item.status)
    strength = evidence_strength(item.confidence)
    prediction_text = (
        format_clock(item.predicted_seconds)
        if item.predicted_seconds is not None
        else "No direct prediction"
    )

    render_html(
        f"""
        <div class="pp-card">
            <div style="
                display:flex;
                justify-content:space-between;
                align-items:flex-start;
                gap:1rem;
            ">
                <div>
                    <div class="pp-card-label">Specialist coach</div>
                    <div class="pp-card-title">{safe_text(item.title)}</div>
                </div>
                <div class="pp-status">{safe_text(status)}</div>
            </div>

            <div class="pp-card-copy">{safe_text(item.summary)}</div>

            <div style="
                display:grid;
                grid-template-columns:repeat(3, minmax(0, 1fr));
                gap:0.8rem;
                margin-top:1rem;
                padding-top:0.9rem;
                border-top:1px solid var(--pp-border);
            ">
                <div>
                    <div class="pp-stat-label">Evidence strength</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(strength)}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Confidence</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {item.confidence:.0%}
                    </div>
                </div>
                <div>
                    <div class="pp-stat-label">Goal estimate</div>
                    <div class="pp-stat-value" style="font-size:1rem;">
                        {safe_text(prediction_text)}
                    </div>
                </div>
            </div>
        </div>
        """
    )

    strengths = item.metadata.get("strengths", [])
    limitations = item.metadata.get("limitations", [])

    if strengths or limitations:
        with st.expander(f"Why does {item.title} believe this?"):
            if strengths:
                st.markdown("**Strengths**")
                for strength in strengths:
                    st.write(f"✓ {strength}")

            if limitations:
                st.markdown("**Limitations**")
                for limitation in limitations:
                    st.write(f"• {limitation}")

            latest_workout = item.metadata.get("latest_workout")
            best_evidence = item.metadata.get("best_evidence")
            top_workouts = item.metadata.get("top_workouts", [])

            if latest_workout and best_evidence:
                st.markdown("**Workout Coach evidence selection**")
                st.write(
                    f"Latest: {latest_workout.get('description', '—')} · "
                    f"{latest_workout.get('date', '—')} · "
                    f"trust {latest_workout.get('trust_score', 0):.0f}/100"
                )
                st.write(
                    f"Best current evidence: "
                    f"{best_evidence.get('description', '—')} · "
                    f"{best_evidence.get('date', '—')} · "
                    f"trust {best_evidence.get('trust_score', 0):.0f}/100"
                )

                warning = item.metadata.get("representative_warning")
                if warning:
                    st.warning(warning)

            historical_similarity = item.metadata.get(
                "historical_similarity"
            )
            if isinstance(historical_similarity, dict):
                st.markdown("**Historical workout matches**")

                match_count = historical_similarity.get(
                    "match_count",
                    0,
                )
                distinct_workouts = historical_similarity.get(
                    "distinct_workout_count",
                    0,
                )
                distinct_races = historical_similarity.get(
                    "distinct_race_count",
                    0,
                )
                similarity_confidence = historical_similarity.get(
                    "confidence",
                    0,
                )

                similarity_columns = st.columns(4)
                similarity_columns[0].metric(
                    "Strong matches",
                    match_count,
                )
                similarity_columns[1].metric(
                    "Workouts searched",
                    distinct_workouts,
                )
                similarity_columns[2].metric(
                    "Linked races",
                    distinct_races,
                )
                similarity_columns[3].metric(
                    "Match confidence",
                    f"{similarity_confidence:.0%}",
                )

                matches = historical_similarity.get("matches", [])

                if matches:
                    st.caption(
                        "These matches explain the athlete's historical "
                        "workout evidence."
                    )

                    for index, match in enumerate(
                        matches[:5],
                        start=1,
                    ):
                        race_distance = match.get(
                            "race_distance_km",
                            0,
                        )
                        st.write(
                            f"**{index}. "
                            f"{match.get('workout_date', '—')} · "
                            f"{match.get('similarity', 0):.0%} similar**"
                        )
                        st.write(
                            f"Race {match.get('days_after', 0)} days later: "
                            f"{race_distance:.2f} km in "
                            f"{format_clock(match.get('race_time_s'))} "
                            f"({match.get('race_date', '—')})"
                        )

                        reasons = match.get("reasons", [])
                        if reasons:
                            st.caption(
                                "Why it matched: "
                                + "; ".join(reasons)
                            )

                        differences = match.get("differences", [])
                        if differences:
                            st.caption(
                                "Main differences: "
                                + "; ".join(differences)
                            )
                else:
                    st.info(
                        "No sufficiently similar linked historical "
                        "workout was found yet."
                    )

                for limitation in historical_similarity.get(
                    "limitations",
                    [],
                ):
                    st.caption("Similarity note: " + limitation)

            best_workout_dna = item.metadata.get(
                "best_workout_dna"
            )
            latest_workout_dna = item.metadata.get(
                "latest_workout_dna"
            )

            if isinstance(best_workout_dna, dict):
                st.markdown("**Workout DNA**")

                dna_columns = st.columns(4)
                dna_columns[0].metric(
                    "Primary intent",
                    best_workout_dna.get(
                        "primary_label",
                        "Unknown",
                    ),
                )
                dna_columns[1].metric(
                    "Archetype",
                    best_workout_dna.get(
                        "archetype",
                        "Structured workout",
                    ),
                )
                dna_columns[2].metric(
                    "DNA confidence",
                    f"{best_workout_dna.get('confidence', 0):.0%}",
                )
                dna_columns[3].metric(
                    "Execution",
                    (
                        f"{best_workout_dna.get('execution_quality'):.0f}/100"
                        if best_workout_dna.get("execution_quality")
                        is not None
                        else "—"
                    ),
                )

                st.caption(
                    "Workout DNA describes the physiological purpose of the "
                    "best current evidence, rather than only its lap pattern."
                )

                stimulus_scores = best_workout_dna.get(
                    "stimulus_scores",
                    {},
                )

                labels = {
                    "threshold": "❤️ Threshold",
                    "speed": "⚡ Speed / VO₂",
                    "endurance": "🧱 Endurance",
                    "aerobic": "😊 Aerobic",
                }

                for system_key in (
                    "threshold",
                    "speed",
                    "endurance",
                    "aerobic",
                ):
                    score = float(
                        stimulus_scores.get(system_key, 0) or 0
                    )
                    st.write(
                        f"{labels[system_key]} — **{score:.0f}/100**"
                    )
                    st.progress(
                        min(max(score / 100.0, 0.0), 1.0)
                    )

                secondary = best_workout_dna.get(
                    "secondary_systems",
                    [],
                )
                if secondary:
                    st.caption(
                        "Secondary systems: "
                        + ", ".join(
                            system.replace("_", " ").title()
                            for system in secondary
                        )
                    )

                with st.expander("Why this Workout DNA?"):
                    reasons = best_workout_dna.get(
                        "reasons",
                        [],
                    )
                    limitations = best_workout_dna.get(
                        "limitations",
                        [],
                    )

                    if reasons:
                        st.markdown("**Evidence**")
                        for reason in reasons:
                            st.write(f"✓ {reason}")

                    if limitations:
                        st.markdown("**Limitations**")
                        for limitation in limitations:
                            st.write(f"• {limitation}")

                    if (
                        isinstance(latest_workout_dna, dict)
                        and latest_workout_dna.get("activity_id")
                        != best_workout_dna.get("activity_id")
                    ):
                        st.markdown("**Latest versus best evidence**")
                        st.write(
                            "Latest workout intent: "
                            f"{latest_workout_dna.get('primary_label', 'Unknown')}"
                        )
                        st.write(
                            "Best current evidence intent: "
                            f"{best_workout_dna.get('primary_label', 'Unknown')}"
                        )

            workout_prediction = item.metadata.get(
                "workout_prediction"
            )
            if workout_prediction:
                prediction_source = item.metadata.get(
                    "prediction_source",
                    "formula_fallback",
                )
                source_label = (
                    "PB Shape prediction"
                    if prediction_source == "pb_shape"
                    else "Distance-specific workout prediction"
                    if prediction_source == "distance_relevant_workout"
                    else "Personal cross-distance workout prediction"
                    if prediction_source == "cross_distance_pb_shape"
                    else "Historical similarity prediction"
                    if prediction_source == "historical_similarity"
                    else "Formula fallback prediction"
                )

                st.markdown(f"**{source_label}**")
                prediction_columns = st.columns(3)
                prediction_columns[0].metric(
                    "Central estimate",
                    format_clock(
                        workout_prediction.get("central_seconds")
                    ),
                )
                prediction_columns[1].metric(
                    "Likely range",
                    (
                        f"{format_clock(workout_prediction.get('low_seconds'))}"
                        f"–{format_clock(workout_prediction.get('high_seconds'))}"
                    ),
                )
                prediction_columns[2].metric(
                    "Prediction confidence",
                    f"{workout_prediction.get('confidence', 0):.0%}",
                )
                if prediction_source == "pb_shape":
                    st.caption(
                        "Compared with the athlete's recognised workouts "
                        "7-28 days before their PB at this goal distance."
                    )
                elif prediction_source == "distance_relevant_workout":
                    st.caption(
                        "Ideal, flat conditions · based on recent, trusted "
                        "threshold and long-interval work relevant to this "
                        "endurance goal. Short historical races cannot "
                        "override stronger current workout evidence."
                    )
                elif prediction_source == "cross_distance_pb_shape":
                    st.caption(
                        "Ideal, flat conditions · current shorter-distance "
                        "workout shape carried through this athlete's own "
                        "verified PB relationship. This is a cautious fallback, "
                        "not proof of goal-distance endurance."
                    )
                elif prediction_source == "historical_similarity":
                    st.caption(
                        "Ideal, flat conditions · based on "
                        f"{workout_prediction.get('distinct_race_count', 0)} "
                        "distinct historical race outcome(s) following similar "
                        "workouts. Recognition and prediction confidence remain "
                        "separate."
                    )
                else:
                    st.caption(
                        f"{workout_prediction.get('conditions', 'Ideal conditions')} · "
                        f"based on {workout_prediction.get('estimate_count', 0)} "
                        "representative workout estimate(s). Recognition confidence "
                        "and prediction confidence are deliberately separate."
                    )

                if prediction_source == "pb_shape":
                    st.markdown("**PB benchmark**")
                    pb_columns = st.columns(3)
                    pb_columns[0].metric(
                        "PB",
                        format_clock(
                            workout_prediction.get("pb_time_s")
                        ),
                    )
                    pb_columns[1].metric(
                        "PB date",
                        workout_prediction.get("pb_date", "—"),
                    )
                    shape_percent = workout_prediction.get(
                        "current_shape_percent"
                    )
                    pb_columns[2].metric(
                        "Current PB shape",
                        (
                            f"{shape_percent:.1f}%"
                            if shape_percent is not None
                            else "—"
                        ),
                    )

                    with st.expander(
                        "Workouts behind the PB Shape comparison"
                    ):
                        for match in workout_prediction.get(
                            "matches",
                            [],
                        ):
                            st.write(
                                f"**{match.get('date', '—')} · "
                                f"{match.get('similarity', 0):.0%} similar**"
                            )
                            st.write(
                                "PB-shape equivalent: "
                                f"{format_clock(match.get('estimated_seconds'))}"
                            )
                            reasons = match.get("reasons", [])
                            if reasons:
                                st.caption(
                                    "Why matched: " + "; ".join(reasons)
                                )
                            differences = match.get("differences", [])
                            if differences:
                                st.caption(
                                    "Differences: "
                                    + "; ".join(differences)
                                )

                        for limitation in workout_prediction.get(
                            "limitations",
                            [],
                        ):
                            st.caption("PB Shape note: " + limitation)

                elif prediction_source == "distance_relevant_workout":
                    with st.expander(
                        "Distance-relevant workouts behind this prediction"
                    ):
                        for estimate in workout_prediction.get(
                            "estimates",
                            [],
                        ):
                            st.write(
                                f"**{estimate.get('date', '—')} · "
                                f"{estimate.get('title', '—')}**"
                            )
                            st.write(
                                "Goal-distance estimate: "
                                f"{format_clock(estimate.get('predicted_seconds'))} "
                                "· relevant threshold / long-interval work "
                                f"{estimate.get('relevant_work_distance_km', 0):.2f} km"
                            )

                        pb_anchor = workout_prediction.get(
                            "pb_anchor_seconds"
                        )
                        if pb_anchor is not None:
                            st.caption(
                                "Lightly anchored to the athlete's actual "
                                "same-distance PB: "
                                f"{format_clock(pb_anchor)}."
                            )

                        historical_count = workout_prediction.get(
                            "historical_outcome_count",
                            0,
                        )
                        representative_count = workout_prediction.get(
                            "representative_race_count",
                            0,
                        )
                        if historical_count > representative_count:
                            st.caption(
                                f"{historical_count - representative_count} "
                                "shorter or older linked race outcome(s) "
                                "were not allowed to dominate this "
                                "longer-distance prediction."
                            )

                elif prediction_source == "cross_distance_pb_shape":
                    with st.expander(
                        "Personal PB relationship behind this prediction"
                    ):
                        source_distance = workout_prediction.get(
                            "source_distance_km",
                            0,
                        )
                        target_distance = workout_prediction.get(
                            "target_distance_km",
                            0,
                        )
                        st.write(
                            f"**{source_distance:g} km current workout shape:** "
                            f"{format_clock(workout_prediction.get('source_current_seconds'))}"
                        )
                        st.write(
                            f"**{source_distance:g} km PB:** "
                            f"{format_clock(workout_prediction.get('source_pb_seconds'))}"
                        )
                        st.write(
                            f"**{target_distance:g} km verified PB:** "
                            f"{format_clock(workout_prediction.get('target_pb_seconds'))} "
                            f"on {workout_prediction.get('target_pb_date', '—')}"
                        )
                        st.caption(
                            "Current shape ratio applied: "
                            f"{workout_prediction.get('shape_ratio', 1):.1%}. "
                            "Direct race and distance-specific workout evidence "
                            "continue to carry more weight."
                        )

                elif prediction_source == "historical_similarity":
                    with st.expander(
                        "Historical outcomes behind this prediction"
                    ):
                        for outcome in workout_prediction.get(
                            "outcomes",
                            [],
                        ):
                            st.write(
                                f"**Workout {outcome.get('workout_date', '—')} · "
                                f"{outcome.get('similarity', 0):.0%} similar**"
                            )
                            st.write(
                                f"Race {outcome.get('days_after', 0)} days later: "
                                f"{outcome.get('race_distance_km', 0):.2f} km in "
                                f"{format_clock(outcome.get('race_time_s'))} · "
                                "goal-distance equivalent "
                                f"{format_clock(outcome.get('equivalent_goal_time_s'))}"
                            )
                            race_age = outcome.get("race_age_days")
                            if race_age is not None:
                                st.caption(
                                    f"Race evidence: {race_age} days old · "
                                    "selected-distance relevance "
                                    f"{outcome.get('distance_relevance', 0):.0%}"
                                )
                            reasons = outcome.get("reasons", [])
                            if reasons:
                                st.caption(
                                    "Why matched: " + "; ".join(reasons)
                                )

                        for limitation in workout_prediction.get(
                            "limitations",
                            [],
                        ):
                            st.caption("Prediction note: " + limitation)
                else:
                    with st.expander(
                        "How each workout predicted the goal"
                    ):
                        for estimate in workout_prediction.get(
                            "estimates",
                            [],
                        ):
                            st.write(
                                f"**{estimate.get('date', '—')} · "
                                f"{estimate.get('description', '—')}**"
                            )
                            st.write(
                                f"Estimate: "
                                f"{format_clock(estimate.get('predicted_seconds'))} · "
                                f"prediction quality "
                                f"{estimate.get('quality', 0):.0%} · "
                                f"trust {estimate.get('trust_score', 0):.0f}/100"
                            )

                            component_summary = estimate.get(
                                "component_summary"
                            )
                            if component_summary:
                                st.caption(
                                    "Components: " + component_summary
                                )

                            for component in estimate.get(
                                "components",
                                [],
                            ):
                                pace_seconds = component.get(
                                    "average_pace_s_per_km"
                                )
                                pace_text = (
                                    format_pace_value(pace_seconds)
                                    if pace_seconds is not None
                                    else "—"
                                )
                                st.write(
                                    f"• {component.get('label', 'Component')}: "
                                    f"{component.get('rep_count', 0)} reps · "
                                    f"{component.get('average_rep_distance_km', 0):.2f} km "
                                    f"average · {pace_text} · component estimate "
                                    f"{format_clock(component.get('predicted_seconds'))}"
                                )

            phase_engine = item.metadata.get("workout_phases")
            if isinstance(phase_engine, dict):
                st.markdown("**Reconstructed workout phases**")
                st.caption(
                    f"Source: {phase_engine.get('source', 'unknown')} · "
                    f"confidence {phase_engine.get('confidence', 0):.0%}"
                )

                for phase in phase_engine.get("phases", []):
                    pace_text = format_pace_value(
                        phase.get("pace_s_per_km")
                    )
                    recovery = phase.get("recovery_duration_s")
                    recovery_text = (
                        f" · recovery {recovery:.0f}s"
                        if recovery is not None
                        else ""
                    )
                    st.write(
                        f"• **{phase.get('label', 'Phase')}** · "
                        f"{phase.get('rep_count', 1)} block(s) · "
                        f"{phase.get('distance_km', 0):.2f} km · "
                        f"{format_clock(phase.get('duration_s'))} · "
                        f"{pace_text}{recovery_text}"
                    )

                limitations = phase_engine.get("limitations", [])
                if limitations:
                    for limitation in limitations:
                        st.caption("Limitation: " + limitation)

            if top_workouts:
                st.markdown("**Strongest five recent workouts**")
                for workout_item in top_workouts:
                    execution = workout_item.get("execution_score")
                    execution_text = (
                        f" · execution {execution:.0f}/100"
                        if execution is not None
                        else ""
                    )
                    st.write(
                        f"{workout_item.get('rank', '—')}. "
                        f"{workout_item.get('date', '—')} · "
                        f"{workout_item.get('description', '—')} · "
                        f"trust {workout_item.get('trust_score', 0):.0f}/100"
                        f"{execution_text}"
                    )
                    reasons = workout_item.get("trust_reasons", [])
                    if reasons:
                        st.caption("Why trusted: " + "; ".join(reasons))

            workout_trend = item.metadata.get("trend")
            if isinstance(workout_trend, dict):
                st.markdown("**Comparable workout trend**")
                st.write(
                    f"{workout_trend.get('label', '—')} "
                    f"({str(workout_trend.get('confidence', 'Limited')).lower()} "
                    f"confidence; {workout_trend.get('sample_size', 0)} "
                    "comparable session(s))"
                )
                change = workout_trend.get("change_seconds_per_km")
                if change is not None:
                    direction = "faster" if change > 0 else "slower"
                    st.write(
                        f"Recent comparable rep pace is "
                        f"{abs(change):.1f} sec/km {direction}."
                    )

            workout_json = item.metadata.get("workout_json")
            if workout_json:
                st.markdown("**Workout structure**")
                st.write(
                    f"Type: {item.metadata.get('workout_type', '—')}"
                )

                execution = item.metadata.get("execution_score")
                if execution is not None:
                    st.write(f"Execution score: {execution:.0f}/100")

                variation = item.metadata.get(
                    "rep_pace_variation_percent"
                )
                if variation is not None:
                    st.write(
                        f"Rep pace variation: {variation:.1f}%"
                    )

                work_splits = workout_json.get("work_splits", [])
                if work_splits:
                    st.markdown("**Work reps**")
                    for rep in work_splits:
                        st.write(
                            f"Rep {rep.get('index', '—')}: "
                            f"{rep.get('distance_km', 0):.3f} km · "
                            f"{rep.get('duration', '—')} · "
                            f"{rep.get('pace', '—')}"
                        )

                recoveries = workout_json.get("recovery_splits", [])
                if recoveries:
                    st.markdown("**Recoveries**")
                    for recovery in recoveries:
                        st.write(
                            f"{recovery.get('distance_km', 0):.3f} km · "
                            f"{recovery.get('duration', '—')}"
                        )

            trend = item.metadata.get("trend")
            if trend:
                recent_pace = item.metadata.get(
                    "recent_adjusted_pace_seconds_per_km"
                )
                previous_pace = item.metadata.get(
                    "previous_adjusted_pace_seconds_per_km"
                )
                change = item.metadata.get("change_seconds_per_km")
                trend_confidence = item.metadata.get(
                    "trend_confidence",
                    "Limited",
                )

                st.markdown("**Trend comparison**")
                st.write(
                    f"Conclusion: {trend} "
                    f"({trend_confidence.lower()} confidence)"
                )

                if recent_pace is not None:
                    st.write(
                        "Recent adjusted threshold pace: "
                        f"{seconds_to_pace(recent_pace)}/km "
                        f"from {item.metadata.get('recent_session_count', 0)} "
                        "session(s)"
                    )

                if previous_pace is not None:
                    st.write(
                        "Earlier adjusted threshold pace: "
                        f"{seconds_to_pace(previous_pace)}/km "
                        f"from {item.metadata.get('previous_session_count', 0)} "
                        "session(s)"
                    )

                if change is not None:
                    direction = "faster" if change > 0 else "slower"
                    st.write(
                        f"Difference: {abs(change):.1f} sec/km {direction}"
                    )

                recommendation = item.metadata.get("recommendation")
                if recommendation:
                    st.write(f"Recommendation: {recommendation}")

            candidates = item.metadata.get("candidate_debug", [])
            if candidates:
                st.markdown("**Top sessions considered**")
                for index, candidate in enumerate(candidates, start=1):
                    moving_ratio = candidate.get("moving_ratio")
                    moving_text = (
                        f"{moving_ratio:.1%}"
                        if moving_ratio is not None
                        else "—"
                    )
                    pace_text = (
                        candidate.get("equivalent_pace")
                        or candidate.get("elapsed")
                        or "—"
                    )
                    workout = candidate.get("workout") or {}
                    workout_text = workout.get("description")
                    st.write(
                        f"{index}. {candidate.get('date', '—')} · "
                        f"{candidate.get('title', 'Untitled')} · "
                        f"{candidate.get('distance_km', 0):.2f} km · "
                        f"{pace_text} · moving {moving_text} · "
                        f"score {candidate.get('score', 0):.1f}"
                    )
                    if workout_text:
                        st.caption(
                            f"Workout decoder: {workout_text} "
                            f"({workout.get('confidence', 0):.0%} confidence)"
                        )


def render_placeholder_coach(title, description):
    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Specialist coach</div>
            <div class="pp-card-title">{safe_text(title)}</div>
            <div class="pp-card-copy">{safe_text(description)}</div>
            <div style="margin-top:0.8rem;">
                <span class="pp-status pp-status-warning">Coming soon</span>
            </div>
        </div>
        """
    )


def render_coach_evidence_panel(evidence_bundle):
    specialist_items = [
        item
        for item in evidence_bundle.items
        if item.key != "activity_history"
    ]
    history_items = [
        item
        for item in evidence_bundle.items
        if item.key == "activity_history"
    ]

    render_html(
        f"""
        <div class="pp-card pp-card-hero">
            <div class="pp-card-label">Your Coaching Team</div>
            <div class="pp-card-title">
                {len(specialist_items)} specialist coach(es) have reported
            </div>
            <div class="pp-card-copy">
                Overall evidence strength is
                <strong>
                    {safe_text(evidence_strength(evidence_bundle.confidence))}
                </strong>
                from
                <strong>{evidence_bundle.total_sample_size:,}</strong>
                observations.
            </div>
            <div style="margin-top:0.8rem;">
                <span class="pp-status">
                    {evidence_bundle.confidence:.0%} evidence confidence
                </span>
            </div>
        </div>
        """
    )

    cards = [*specialist_items, *history_items]

    for index in range(0, len(cards), 2):
        left, right = st.columns(2, gap="medium")

        with left:
            render_evidence_card(cards[index])

        if index + 1 < len(cards):
            with right:
                render_evidence_card(cards[index + 1])

    placeholder_left, placeholder_right = st.columns(2, gap="medium")

    with placeholder_left:
        render_placeholder_coach(
            "Easy Run Coach",
            "Will interpret aerobic efficiency and best easy-run evidence.",
        )

    with placeholder_right:
        render_placeholder_coach(
            "Environment Coach",
            "Will specialise in heat, humidity, terrain, wind and surface.",
        )



def render_recent_activities(
    run_profiles,
    recognition_index,
    timing_context,
):
    cards = []

    for run in run_profiles[:5]:
        sport_name, fallback_title = get_sport_name(run.sport_id)
        performance = equivalent_performance(run)
        key = recognition_key(run)
        recognition = recognition_index.get(key)
        timing = timing_context.get(key, {})

        title = run.title or fallback_title
        route_name = timing.get("route_name")
        moving_percent = timing.get("moving_percent")
        wind_speed = timing.get("wind_speed")

        fact_bits = []

        if run.distance_km is not None and run.distance_km > 0:
            fact_bits.append(
                f"📏 {format_distance_miles(run.distance_km)}"
            )

        if run.moving_time_seconds is not None:
            fact_bits.append(
                f"⏱️ {format_duration(run.moving_time_seconds)}"
            )

        if performance is not None:
            fact_bits.append(
                "⚡ "
                + format_pace_per_mile(
                    performance.actual_pace_seconds_per_km
                )
            )

        if run.avg_hr is not None:
            fact_bits.append(f"❤️ {run.avg_hr:.0f} bpm")

        if moving_percent is not None:
            fact_bits.append(
                f"▶️ {moving_percent:.1f}% moving"
            )

        environment_bits = []

        if run.temperature_c is not None:
            environment_bits.append(
                f"🌡️ {run.temperature_c:.0f}°C"
            )

        if run.humidity is not None:
            environment_bits.append(
                f"💧 {run.humidity:.0f}% humidity"
            )

        if (
            performance is not None
            and performance.adjustment.dew_point_c is not None
        ):
            environment_bits.append(
                f"💦 DP {performance.adjustment.dew_point_c:.0f}°C"
            )

        if wind_speed is not None:
            environment_bits.append(
                f"💨 {wind_speed:.0f} km/h"
            )

        if run.elevation_m is not None and run.elevation_m > 0:
            environment_bits.append(
                f"⛰️ {run.elevation_m:.0f} m"
            )

        trail_found = False

        if recognition is not None:
            trail_found = any(
                (
                    "trail" in factor.lower()
                    or "off-road" in factor.lower()
                )
                for factor in recognition.environment_factors
            )

        if not trail_found:
            lower_title = str(title).lower()
            trail_found = (
                "trail" in lower_title
                or "off road" in lower_title
                or "off-road" in lower_title
            )

        if trail_found:
            environment_bits.append("🌲 Trail")

        if recognition is not None:
            celebration = (
                f"{recognition.icon} "
                f"{safe_text(recognition.celebration)}"
            )

            rank_bits = [
                (
                    f"#{recognition.rank} of {recognition.total} "
                    f"{recognition.category_label} sessions"
                )
            ]

            if recognition.rank_12m is not None:
                rank_bits.append(
                    f"#{recognition.rank_12m} in the last 12 months"
                )

            if recognition.rank_90d is not None:
                rank_bits.append(
                    f"#{recognition.rank_90d} in the last 90 days"
                )

            recognition_detail = " · ".join(rank_bits)

            secondary = [
                achievement
                for achievement in recognition.achievements
                if achievement.label != recognition.celebration
            ]

            positive_bits = []

            for achievement in secondary[:2]:
                positive_bits.append(
                    f"{achievement.icon} {achievement.label}"
                )

            if recognition.trend_label:
                positive_bits.append(
                    f"📈 {recognition.trend_label}"
                )

            positives = (
                " · ".join(positive_bits)
                if positive_bits
                else recognition.positive_detail
            )

            evidence_bits = [
                recognition.confidence_label,
            ]

            if (
                recognition.environment_adjustment_s_per_km
                >= 2
            ):
                evidence_bits.append(
                    "conditions recognised"
                )

            if recognition.continuity_label:
                evidence_bits.append(
                    recognition.continuity_label
                )

            if recognition.provisional:
                evidence_bits.append(
                    "provisional until rep-level Workout DNA"
                )

            evidence_line = " · ".join(evidence_bits)
        else:
            celebration = "✨ Training banked"
            recognition_detail = sport_name
            positives = (
                "Another session added to your training history."
            )
            evidence_line = "Recognition is still learning this session."

        facts = " &nbsp; • &nbsp; ".join(
            safe_text(item)
            for item in fact_bits
        ) or "Training session"

        environment = " &nbsp; • &nbsp; ".join(
            safe_text(item)
            for item in dict.fromkeys(environment_bits)
        ) or "🌤️ No environmental data recorded"

        location = (
            f"📍 {safe_text(route_name)}"
            if route_name
            else safe_text(sport_name)
        )

        cards.append(
            f"""
            <div class="pp-training-card">
                <div class="pp-training-card-top">
                    <div>
                        <div class="pp-training-date">
                            {safe_text(format_date(run.activity_date))}
                        </div>
                        <div class="pp-training-title">
                            {safe_text(title)}
                        </div>
                        <div class="pp-training-location">
                            {location}
                        </div>
                    </div>
                    <div class="pp-training-badge">
                        {celebration}
                    </div>
                </div>

                <div class="pp-training-facts">
                    {facts}
                </div>

                <div class="pp-training-environment">
                    {environment}
                </div>

                <div class="pp-training-recognition">
                    <strong>{celebration}</strong>
                    <span>{safe_text(recognition_detail)}</span>
                    <div class="pp-training-positive">
                        {safe_text(positives)}
                    </div>
                    <div class="pp-training-positive">
                        Evidence: {safe_text(evidence_line)}
                    </div>
                </div>
            </div>
            """
        )

    if not cards:
        cards.append(
            """
            <div class="pp-card-copy">
                No recent activities are available.
            </div>
            """
        )

    render_html(
        f"""
        <div class="pp-card">
            <div class="pp-card-label">Latest training</div>
            <div class="pp-card-title">
                Every run has something to celebrate
            </div>
            <div class="pp-card-copy" style="margin-bottom:0.8rem;">
                Recognition first, ranking as evidence, then the other
                positives the session earned.
            </div>
            {''.join(cards)}
        </div>
        """
    )


def _v21_family_label(family, title=None):
    family = str(family or "").lower()
    labels = {
        "completed": "Completed", "easy": "Easy", "recovery": "Recovery",
        "endurance": "Long Run", "long": "Long Run", "threshold": "Threshold",
        "vo2": "VO₂", "speed": "Speed", "race_pace": "Race Pace", "rest": "Rest",
    }
    return labels.get(family, str(title or family).replace("_", " ").title() or "Run")


def render_v21_coach_home(
    athlete_id, first_name, goal, capability,
    environment_forecast, brain_brief, evidence_bundle,
):
    """Presentation-only v0.21 Coach Home using existing coaching engines."""
    today = datetime.date.today()
    live = build_live_coach_decision(athlete_id)
    weekly = build_adaptive_weekly_plan(athlete_id, today=today)
    goal_name = goal["goal_name"] if goal else "Build your next goal"
    evidence = evidence_strength(evidence_bundle.confidence)

    week_days = weekly.weeks[0].days if weekly.available and weekly.weeks else ()
    day_cards = []
    for index, day in enumerate(week_days):
        day_date = today + datetime.timedelta(days=index - today.weekday())
        classes = ["pp-v21-day"]
        if day_date == today:
            classes.append("today")
        if day.session_family == "completed":
            classes.append("completed")
        detail = day.prescription or day.target or ""
        if len(detail) > 46:
            detail = detail[:43].rstrip() + "…"
        day_cards.append(
            f"""<div class="{' '.join(classes)}">
            <div class="pp-v21-day-name">{safe_text(day.day_name[:3])}</div>
            <div class="pp-v21-day-session">{safe_text(_v21_family_label(day.session_family, day.title))}</div>
            <div class="pp-v21-day-detail">{safe_text(detail)}</div></div>"""
        )

    capability_text = format_clock(capability.central_seconds) if capability.available and capability.central_seconds else "—"
    scenarios = {x.key: x for x in environment_forecast.scenarios} if environment_forecast.available else {}
    ideal = scenarios.get("ideal")
    typical = scenarios.get("typical")
    ideal_text = format_clock(ideal.central_seconds) if ideal else capability_text
    typical_text = format_clock(typical.central_seconds) if typical else "—"

    next_title = live.immediate_label if live else "Building next run"
    next_timing = live.immediate_timing if live else "Timing building"
    next_detail = live.immediate_detail if live else brain_brief.summary
    key_title = live.key_label if live and live.key_label else "Next key session"
    key_day = live.key_day if live and live.key_day else "Building"
    key_detail = live.key_prescription if live and live.key_prescription else "The coaching team is resolving the next quality stimulus."

    render_html(f"""
    <div class="pp-v21-kicker">Coach Home · {safe_text(goal_name)}</div>
    <div class="pp-v21-title">Good morning, {safe_text(first_name)}.</div>
    <div class="pp-v21-subtitle">{safe_text(brain_brief.headline)}
    <strong style="color:var(--pp-ink);"> {safe_text(evidence)} evidence.</strong></div>

    <div class="pp-v21-section-title">This week</div>
    <div class="pp-v21-week">{''.join(day_cards)}</div>

    <div class="pp-v21-grid">
      <div class="pp-v21-card route">
        <div class="pp-v21-label">Up next · {safe_text(next_timing)}</div>
        <div class="pp-v21-card-title">{safe_text(next_title)}</div>
        <div class="pp-v21-copy">{safe_text(next_detail)}</div>
        <div class="pp-v21-pill">Adaptive Coach</div>
      </div>
      <div class="pp-v21-card dark">
        <div class="pp-v21-label">Prediction · {safe_text(goal_name)}</div>
        <div class="pp-v21-predictions">
          <div class="pp-v21-pred"><div class="pp-v21-pred-value">{safe_text(capability_text)}</div><div class="pp-v21-pred-label">Capability</div></div>
          <div class="pp-v21-pred"><div class="pp-v21-pred-value orange">{safe_text(ideal_text)}</div><div class="pp-v21-pred-label">Ideal</div></div>
          <div class="pp-v21-pred"><div class="pp-v21-pred-value green">{safe_text(typical_text)}</div><div class="pp-v21-pred-label">Typical conditions</div></div>
        </div>
        <div class="pp-v21-copy" style="margin-top:.9rem;">Fitness stays separate from environment: conditions change expected performance, not underlying capability.</div>
      </div>
    </div>

    <div class="pp-v21-grid">
      <div class="pp-v21-card">
        <div class="pp-v21-label">Next key session · {safe_text(key_day)}</div>
        <div class="pp-v21-card-title">{safe_text(key_title)}</div>
        <div class="pp-v21-copy">{safe_text(key_detail)}</div>
      </div>
      <div class="pp-v21-card">
        <div class="pp-v21-label">Coach insight</div>
        <div class="pp-v21-card-title">{safe_text(brain_brief.headline)}</div>
        <div class="pp-v21-copy">{safe_text(brain_brief.summary)}</div>
      </div>
    </div>
    """)


def show_dashboard():
    selector_col, _ = st.columns([0.35, 0.65])

    with selector_col:
        athlete_id = render_athlete_selector(
            key="coach_athlete_selector",
            label="Athlete",
            label_visibility="collapsed",
        )

    if athlete_id is None:
        st.warning("No athletes found. Add an athlete first.")
        return

    athlete_connection = get_connection()
    athlete_cursor = athlete_connection.cursor()
    athlete_cursor.execute(
        """
        SELECT first_name, last_name
        FROM athletes
        WHERE id = ?
        """,
        (athlete_id,),
    )
    athlete_row = athlete_cursor.fetchone()
    athlete_connection.close()

    if athlete_row is None:
        st.warning("The selected athlete could not be found.")
        return

    selected = {
        "first_name": athlete_row[0] or "Athlete",
        "last_name": athlete_row[1] or "",
    }

    evidence_connection = get_connection()
    athlete_evidence_profile = build_athlete_evidence_profile(
        evidence_connection,
        athlete_id=athlete_id,
    )
    evidence_connection.close()

    brain = CoachBrain(athlete_id)
    goal = get_active_goal(athlete_id)
    evidence_bundle = brain.build_evidence()
    prediction = brain.goal_prediction()
    brain_brief = brain.morning_brief()

    thresholds = get_athlete_thresholds(athlete_id)
    run_profiles = get_run_profiles(athlete_id, thresholds)
    timing_context = get_recent_activity_timing_context(
        athlete_id
    )
    recognition_index = build_recognition_index(
        run_profiles,
        athlete_id=athlete_id,
    )
    training_blueprint = build_training_blueprint(
        run_profiles,
        athlete_id=athlete_id,
    )
    easy_run_coach = build_easy_run_coach(
        run_profiles,
        evidence_profile=athlete_evidence_profile,
    )

    performance_dna = build_performance_dna(
        evidence_bundle,
        consensus_prediction_s=(
            prediction.predicted_seconds
            if prediction.available
            else None
        ),
        easy_run_coach=easy_run_coach,
    )
    coach_consensus = build_coach_consensus(
        performance_dna,
        consensus_prediction_s=(
            prediction.predicted_seconds
            if prediction.available
            else None
        ),
    )
    capability = build_capability(
        predicted_seconds=(
            prediction.predicted_seconds
            if prediction.available
            else None
        ),
        prediction_confidence=(
            prediction.confidence
            if prediction.available
            else 0.0
        ),
        performance_dna=performance_dna,
        coach_consensus=coach_consensus,
        target_seconds=(
            goal["target_time_s"]
            if goal is not None
            else None
        ),
    )
    personal_environment_profile = build_personal_environment_profile(
        run_profiles,
        athlete_id=athlete_id,
    )
    environment_forecast = build_environment_forecast(
        capability,
        distance_km=goal_distance_km(goal),
        personal_profile=personal_environment_profile,
    )

    current_baseline = build_baseline(
        runs=run_profiles,
        run_type="🟢 Run",
        baseline_name="Current",
        period_days=90,
    )

    all_time_baseline = build_baseline(
        runs=run_profiles,
        run_type="🟢 Run",
        baseline_name="All Time",
        period_days=None,
    )

    best_run = best_easy_run(run_profiles)

    recent_weekly_distance_km, latest_activity_date = (
        get_recent_weekly_average(athlete_id, weeks=26)
    )

    render_v21_coach_home(
        athlete_id=athlete_id,
        first_name=selected["first_name"],
        goal=goal,
        capability=capability,
        environment_forecast=environment_forecast,
        brain_brief=brain_brief,
        evidence_bundle=evidence_bundle,
    )

    st.markdown('<div class="pp-v21-section-title">Coaching team & deep analysis</div>', unsafe_allow_html=True)
    render_coaching_meeting(
        performance_dna,
        prediction,
        coach_consensus,
    )

    render_training_blueprint(
        training_blueprint,
        thresholds,
    )
    render_evidence_engine(athlete_evidence_profile)
    render_easy_run_coach(easy_run_coach)
    render_capability_card(capability)
    render_personal_environment_profile(
        personal_environment_profile
    )
    render_environment_forecast(environment_forecast)

    st.markdown("## Goal and context")

    top_left, top_right = st.columns([1.05, 0.95], gap="medium")

    with top_left:
        render_goal_card(goal, prediction)

    with top_right:
        render_coach_brief(
            current_baseline,
            all_time_baseline,
            brain_brief,
        )

    st.markdown("## This year")
    current_year = datetime.date.today().year

    (
        year_activities,
        _year_distance_km,
        year_moving_time_s,
        _,
    ) = get_year_summary(athlete_id, current_year)

    recent_weekly_distance_miles = recent_weekly_distance_km / (
        METRES_PER_MILE / 1000
    )

    stat1, stat2, stat3, stat4 = st.columns(4, gap="small")

    with stat1:
        render_stat_card(
            "Activities",
            f"{year_activities:,}",
            f"Recorded in {current_year}",
        )

    with stat2:
        latest_context = (
            f"26 weeks ending {latest_activity_date.strftime('%d %b %Y')}"
            if latest_activity_date is not None
            else "No activity date available"
        )
        render_stat_card(
            "Average week",
            f"{recent_weekly_distance_miles:.1f} mi",
            latest_context,
        )

    with stat3:
        render_stat_card(
            "Moving time",
            format_hours(year_moving_time_s),
            "Training time this year",
        )

    with stat4:
        if current_baseline:
            render_stat_card(
                "Easy-run pace",
                format_pace_per_mile(
                    current_baseline.avg_pace_seconds_per_km
                ),
                f"Based on {current_baseline.run_count} recent runs",
            )
        else:
            render_stat_card(
                "Easy-run pace",
                "--",
                "Building your current baseline",
            )

    st.markdown("## What matters now")
    discovery_col, context_col = st.columns([1.15, 0.85], gap="medium")

    with discovery_col:
        render_latest_discovery(best_run)

    with context_col:
        lifetime_activities, _, _, _ = get_lifetime_summary(athlete_id)
        render_html(
            f"""
            <div class="pp-card">
                <div class="pp-card-label">Passport confidence</div>
                <div class="pp-card-title">Very high</div>
                <div class="pp-card-copy">
                    Performance Passport has
                    <strong>{lifetime_activities:,} activities</strong>
                    available for learning about your training history.
                </div>
                <div style="margin-top:0.8rem;">
                    <span class="pp-status">Strong evidence base</span>
                </div>
            </div>
            """
        )

    st.markdown("## Coach evidence")
    render_coach_evidence_panel(evidence_bundle)

    st.markdown("## Latest training")
    render_recent_activities(
        run_profiles,
        recognition_index,
        timing_context,
    )
