from functools import lru_cache
from pathlib import Path

from core.passport_detail import build_passport_detail
from ui.passport import build_passport_html


ROOT = Path(__file__).resolve().parent.parent


@lru_cache(maxsize=2)
def _markup(athlete_id: int) -> str:
    return build_passport_html(build_passport_detail(athlete_id))


def test_passport_surface_uses_richard_real_evidence():
    markup = _markup(1)
    detail = build_passport_detail(1)
    threshold_distance_mi = (
        detail.threshold_evidence.typical_work_distance_km / 1.609344
    )

    assert "Richard Burke" in markup
    assert "152 bpm" in markup
    assert "161 bpm" in markup
    assert "6:19/mi" in markup
    assert "6:10–6:15/mi cautious 12°C equivalent" in markup
    assert "Trail Warrior" in markup
    assert "47% more affected" in markup
    assert "35% less affected" in markup
    assert "103 TRUSTED WORKOUTS" in markup
    assert "31</b> high-confidence decoded threshold workouts" in markup
    assert "5</b> in the strict 12-month pace-trend set" in markup
    assert "2</b> with complete before/after response windows" in markup
    assert f"{threshold_distance_mi:.1f} mi" in markup
    assert "19:08" in markup
    assert "OFFICIAL TIMES ARE NEVER NORMALISED" in markup


def test_passport_surface_keeps_jo_independent_and_uncertainty_visible():
    richard = _markup(1)
    jo = _markup(3)

    assert "Joanne Burke" in jo
    assert "171 bpm" in jo
    assert "187 bpm" in jo
    assert "6:54/mi" in jo
    assert "Still emerging" in jo
    assert "Still learning" in jo
    assert "23 TRUSTED WORKOUTS" in jo
    assert "6:19/mi" not in jo
    assert richard != jo


def test_passport_training_profile_is_evidence_not_medical_zone_claim():
    markup = _markup(1)

    assert "TRAINING PROFILE" in markup
    assert "Recovery" in markup
    assert "Easy aerobic" in markup
    assert "Long Easy" in markup
    assert "Threshold" in markup
    assert "VO₂ development" in markup
    assert "Speed development" in markup
    assert "RPE-led" in markup
    assert "HR lags short work" in markup
    assert "historical patterns, not prescriptions" in markup
    assert "not presented as laboratory measurements" in markup
    assert "Typical distance" in markup
    assert "11.6 mi" in markup


def test_passport_route_and_responsive_contract():
    markup = _markup(1)
    app_source = (ROOT / "app.py").read_text()
    passport_source = (ROOT / "ui" / "passport.py").read_text()

    assert "from ui.passport import show_passport_page" in app_source
    assert 'elif page == "Passport":\n    show_passport_page()' in app_source
    assert "render_athlete_id_selector" in passport_source
    assert "container-type:inline-size" in markup
    assert "@container (max-width:1050px)" in markup
    assert "@container (max-width:760px)" in markup
    assert "@container (max-width:500px)" in markup


def test_passport_hero_is_identity_led_and_preserves_running_zones():
    markup = _markup(1)

    assert "YOUR RUNNING IDENTITY" in markup
    assert "Richard’s performance passport." in markup
    assert "Live profile" in markup
    assert "BEST AGE GRADE" not in markup
    assert "CURRENT ANCHORS" in markup
    assert "TRAINING PROFILE" in markup
    assert "152 bpm" in markup
    assert "161 bpm" in markup
    assert "Health and notes remain private" in markup
    assert ".passport-hero-confidence h2 { color:#fff!important" in markup


def test_share_preview_never_publishes_health_or_creates_a_link():
    markup = _markup(1)

    assert "SHAREABLE PERFORMANCE PROFILE" in markup
    assert "Private · sharing off" in markup
    assert "PREVIEW ONLY" in markup
    assert "No public URL exists" in markup
    assert "HRV, resting heart rate and sleep history" in markup
    assert "no health data leaves this private athlete view" in markup
    assert "Enable sharing" not in markup
