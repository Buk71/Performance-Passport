from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_workout_provider_preserves_order_and_uses_decoder_v4():
    source = (
        ROOT / "core" / "evidence_providers" / "workout.py"
    ).read_text(encoding="utf-8")

    assert "WORKOUT_LIBRARY_DECODER_VERSION = 4" in source
    assert "splits = list(_work_splits(workout))" in source
    assert "structure_shape" in source
    assert "distance_sequence_m" in source


def test_pyramid_signature_is_sequence_specific():
    source = (
        ROOT / "core" / "evidence_providers" / "workout.py"
    ).read_text(encoding="utf-8")

    assert 'return f"{shape}_"' in source
    assert '"pyramid"' in source
    assert '"ascending_ladder"' in source
    assert '"descending_ladder"' in source
