"""Compose existing coaching services into one auditable Training Coach view.

This module does not decide the next run. Adaptive Coach remains responsible
for that decision, Session Designer remains responsible for the prescription,
and Fuel Planner remains responsible for nutrition guidance.
"""

from __future__ import annotations

from dataclasses import dataclass
import datetime

from core.adaptive_coach_live import LiveCoachDecision, build_live_coach_decision
from core.beginner_sessions import BeginnerSessionPrescription, build_couch_to_5k_session
from core.five_to_ten_k_plan import build_five_to_ten_k_plan
from core.runner_journey import (
    COUCH_TO_5K, FIVE_TO_TEN_K, get_active_runner_journey,
    get_journey_current_week, get_five_to_ten_k_current_level,
)
from core.fuel_planner import fuel_guidance_for_demand, training_demand
from core.session_designer import DesignedSession, build_designed_session
from core.cache_version import get_training_intelligence_version
from core.materialized_intelligence import get_or_build_typed_intelligence


@dataclass(frozen=True)
class TrainingAdjustment:
    key: str
    label: str
    direction: str


@dataclass(frozen=True)
class TrainingCoachDetail:
    athlete_id: int
    decision: LiveCoachDecision
    session: DesignedSession | None
    fuel_demand: str
    fuel_focus: str
    fuel_before: str
    fuel_during: str
    fuel_after: str
    adjustments: tuple[TrainingAdjustment, ...]
    beginner_session: BeginnerSessionPrescription | None = None
    beginner_week_number: int | None = None
    five_to_ten_level: int | None = None
    journey_session_day: str | None = None
    journey_session_role: str | None = None
    journey_session_title: str | None = None
    journey_session_detail: str | None = None
    journey_session_counts_for_progression: bool | None = None
    journey_level_title: str | None = None
    journey_level_emphasis: str | None = None
    journey_long_run_km: float | None = None
    model_version: int = 3


def _designer_family(decision: LiveCoachDecision) -> str | None:
    """Translate live-week family names into Session Designer vocabulary."""
    family = str(decision.key_family or "").strip().lower()
    if family in {
        "recovery", "easy", "threshold", "vo2", "speed", "endurance",
        "race_pace",
    }:
        return family
    if family == "long":
        return "endurance"
    if family == "race":
        return "race_pace"

    evidence = " ".join(
        str(value or "")
        for value in (
            decision.key_label,
            decision.key_prescription,
            decision.immediate_label,
        )
    ).lower()
    if "threshold" in evidence or "tempo" in evidence:
        return "threshold"
    if "vo2" in evidence or "vo₂" in evidence:
        return "vo2"
    if "speed" in evidence or "repetition" in evidence:
        return "speed"
    if "long" in evidence or "endurance" in evidence:
        return "endurance"
    if "race" in evidence:
        return "race_pace"
    return None


def _adjustments() -> tuple[TrainingAdjustment, ...]:
    return (
        TrainingAdjustment(
            key="fatigue",
            label="Unusually fatigued",
            direction=(
                "Move the demanding session and keep the day easy or rest. "
                "Do not repay it by placing two hard days together."
            ),
        ),
        TrainingAdjustment(
            key="pain",
            label="Pain or altered movement",
            direction=(
                "Do not substitute another workout. Stop if pain is sharp, "
                "worsening or changes your gait; seek professional advice if it persists."
            ),
        ),
        TrainingAdjustment(
            key="time",
            label="Short of time",
            direction=(
                "Keep the warm-up and cool-down. Reduce main-set volume rather "
                "than increasing pace or removing recovery."
            ),
        ),
    )


def _build_training_coach_detail_uncached(
    athlete_id: int,
    *,
    today: datetime.date | None = None,
) -> TrainingCoachDetail | None:
    """Build one athlete's Training Coach page from established services."""
    decision = build_live_coach_decision(athlete_id, today=today)
    if decision is None:
        return None

    journey = get_active_runner_journey(athlete_id)
    if journey is not None and journey.journey_type == FIVE_TO_TEN_K:
        level = get_five_to_ten_k_current_level(journey)
        plan = build_five_to_ten_k_plan(
            athlete_id=athlete_id,
            sessions_per_week=journey.sessions_per_week,
            entry_stage=journey.entry_stage,
            current_level=level,
            reference_date=today or datetime.date.today(),
        )
        current = plan.levels[level - 1]
        names = ("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")
        effective_today = today or datetime.date.today()
        next_session = min(
            current.sessions,
            key=lambda item: (names.index(item.day) - effective_today.weekday()) % 7,
        )
        demand = (
            "Long" if next_session.role == "Long easy"
            else "Quality" if "Quality" in next_session.role
            else "Easy"
        )
        focus, before, during, after = fuel_guidance_for_demand(demand)
        return TrainingCoachDetail(
            athlete_id=athlete_id, decision=decision, session=None,
            fuel_demand=demand, fuel_focus=focus, fuel_before=before,
            fuel_during=during, fuel_after=after, adjustments=_adjustments(),
            five_to_ten_level=level,
            journey_session_day=next_session.day,
            journey_session_role=next_session.role,
            journey_session_title=next_session.title,
            journey_session_detail=next_session.detail,
            journey_session_counts_for_progression=next_session.counts_for_progression,
            journey_level_title=current.title,
            journey_level_emphasis=current.emphasis,
            journey_long_run_km=current.long_run_km,
        )

    if journey is not None and journey.journey_type == COUCH_TO_5K:
        focus, before, during, after = fuel_guidance_for_demand("Easy")
        return TrainingCoachDetail(
            athlete_id=athlete_id, decision=decision, session=None,
            fuel_demand="Easy", fuel_focus=focus, fuel_before=before,
            fuel_during=during, fuel_after=after, adjustments=_adjustments(),
            beginner_session=build_couch_to_5k_session(journey.current_stage),
            beginner_week_number=get_journey_current_week(journey),
        )

    family = _designer_family(decision)
    main_set = (
        (decision.key_prescription,)
        if decision.key_prescription else None
    )
    session = build_designed_session(
        athlete_id,
        family_override=family,
        main_set_override=main_set,
        timing_override=decision.key_day,
        confidence_override=decision.confidence,
        confidence_label_override=decision.confidence_label,
        why_override=decision.why,
    )

    # Fuel advice belongs to the immediate run at the top of the page. The
    # detailed key session may be several days away and must not make an easy
    # or recovery day look like a quality-fuel day.
    demand_text = " ".join(
        value for value in (
            decision.immediate_label,
            decision.immediate_detail,
        ) if value
    )
    demand = training_demand(demand_text)
    focus, before, during, after = fuel_guidance_for_demand(demand)

    return TrainingCoachDetail(
        athlete_id=athlete_id,
        decision=decision,
        session=session,
        fuel_demand=demand,
        fuel_focus=focus,
        fuel_before=before,
        fuel_during=during,
        fuel_after=after,
        adjustments=_adjustments(),
    )


def build_training_coach_detail(
    athlete_id: int,
    *,
    today: datetime.date | None = None,
) -> TrainingCoachDetail | None:
    """Build or reuse today's Training Coach intelligence.

    The calendar date is part of the key because "today", operational-week
    placement and next-session timing are intentionally day-sensitive.
    """
    effective_today = today or datetime.date.today()
    source_version = tuple(get_training_intelligence_version(int(athlete_id)))
    key = f"training.coach_detail.v3.{effective_today.isoformat()}"

    return get_or_build_typed_intelligence(
        int(athlete_id),
        key,
        source_version=source_version,
        horizon="recent",
        builder=lambda: _build_training_coach_detail_uncached(
            int(athlete_id),
            today=effective_today,
        ),
        source_version_provider=lambda: tuple(
            get_training_intelligence_version(int(athlete_id))
        ),
    )
