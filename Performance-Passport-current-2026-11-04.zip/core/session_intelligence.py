from __future__ import annotations

import json
from dataclasses import dataclass
from statistics import median
from typing import Any

from core.session import (
    CoachRoute,
    Session,
    SessionEvidence,
    SessionPurpose,
    SessionType,
)
from core.database import get_activity_overrides, get_athlete_sport_roles
from core.race_detection import score_race_evidence
from core.session_patterns import analyse_session_patterns
from core.splits import is_boundary_fragment, parse_splits, recognise_workout
from core.workout_title_intent import parse_workout_title


RACE_WORDS = (
    "race", "parkrun", "5k", "10k", "half marathon",
    "marathon", "cross country", "xc", "handicap",
)

WORKOUT_WORDS = (
    "threshold", "tempo", "interval", "intervals", "reps",
    "repetition", "repetitions", "fartlek", "hill reps",
    "track session", "vo2", "cruise", "strides",
    "drills", "ladder", "workout", "session",
)

# Downstream features may use a confident shared classification as their source
# of truth. Below this floor, they should retain conservative legacy/fallback
# handling rather than turning an ambiguous historical split pattern into fact.
RELIABLE_SESSION_CONFIDENCE = 0.70


@dataclass(frozen=True)
class ActivityFacts:
    activity_id: int
    athlete_id: int
    activity_date: str | None
    title: str
    sport_id: str | None
    distance_km: float | None
    moving_time_s: float | None
    elapsed_time_s: float | None
    avg_hr: float | None
    max_hr: float | None
    elevation_up_m: float | None
    temperature_c: float | None
    humidity: float | None
    wind_speed: float | None
    route_name: str | None
    raw_json_text: str | None
    athlete_lt2_hr: float | None = None
    athlete_max_hr: float | None = None
    athlete_lt1_hr: float | None = None


def _contains_any(title: str, words: tuple[str, ...]) -> bool:
    normalised = (title or "").lower()
    return any(word in normalised for word in words)


def _extract_raw_splits(raw_json_text: str | None) -> str | None:
    if not raw_json_text:
        return None
    try:
        raw = json.loads(raw_json_text)
    except (TypeError, json.JSONDecodeError):
        return None
    return raw.get("splits") or raw.get("splitsCustom")


def _easy_run_with_strides(
    facts: ActivityFacts,
    raw_splits: str | None,
) -> dict[str, Any] | None:
    """Keep short finishing strides from reclassifying an otherwise easy run.

    Watches commonly auto-lap the easy portion every kilometre and then record
    manually lapped 100-200 m strides. A generic split recogniser can invert
    those roles, calling the easy auto-laps "work" and the faster strides
    "recovery". This recognises the full chronological shape instead.
    """
    title = (facts.title or "").lower()
    explicit_quality = (
        "threshold", "tempo", "interval", "reps", "fartlek", "ladder",
        "track session", "vo2", "5k pace", "10k pace", "hill session",
    )
    if any(word in title for word in explicit_quality):
        return None

    if (
        facts.avg_hr is not None
        and facts.athlete_lt2_hr is not None
        and facts.avg_hr >= facts.athlete_lt2_hr * 0.95
    ):
        return None

    splits = parse_splits(raw_splits)
    substantial = [
        split for split in splits
        if split.distance_km >= 0.45
        and split.duration_s >= 100
        and split.pace_s_per_km is not None
    ]
    explicitly_easy = "easy" in title or "stride" in title or "recovery" in title
    if len(substantial) < (2 if explicitly_easy else 3):
        return None

    easy_pace = float(median(split.pace_s_per_km for split in substantial))
    stride_candidates = [
        split for split in splits
        if 0.06 <= split.distance_km <= 0.22
        and 12 <= split.duration_s <= 65
        and split.pace_s_per_km is not None
        and split.pace_s_per_km <= easy_pace * 0.88
    ]
    if len(stride_candidates) < 3:
        return None

    first_stride = min(split.index for split in stride_candidates)
    easy_before = [split for split in substantial if split.index < first_stride]
    easy_distance = sum(split.distance_km for split in easy_before)
    easy_duration = sum(split.duration_s for split in easy_before)
    stride_distance = sum(split.distance_km for split in stride_candidates)
    total_distance = facts.distance_km or sum(split.distance_km for split in splits)

    if (
        len(easy_before) < (2 if explicitly_easy else 3)
        or easy_duration < (600 if explicitly_easy else 900)
        or total_distance <= 0
        or easy_distance / total_distance < 0.55
        or stride_distance / total_distance > 0.25
    ):
        return None

    return {
        "split_count": len(splits),
        "easy_auto_lap_count": len(easy_before),
        "easy_distance_km": round(easy_distance, 3),
        "easy_pace_s_per_km": round(easy_pace, 1),
        "stride_count": len(stride_candidates),
        "stride_distance_km": round(stride_distance, 3),
        "stride_average_distance_km": round(
            stride_distance / len(stride_candidates), 3
        ),
        "reason": (
            "Most of the activity was continuous easy running; short faster "
            "strides were grouped near the finish and do not establish an "
            "interval workout."
        ),
    }


def _standalone_strides(
    facts: ActivityFacts,
    raw_splits: str | None,
) -> dict[str, Any] | None:
    """A separately saved handful of strides is not a race-pace workout."""
    if facts.distance_km is None or facts.distance_km > 1.6:
        return None
    if facts.moving_time_s is not None and facts.moving_time_s > 1_100:
        return None
    splits = parse_splits(raw_splits)
    faster = [
        item for item in splits
        if 0.055 <= item.distance_km <= 0.22
        and 10 <= item.duration_s <= 65
        and item.pace_s_per_km is not None
    ]
    if len(faster) < 3 or sum(item.distance_km for item in faster) > 1.05:
        return None
    return {
        "split_count": len(splits),
        "stride_count": len(faster),
        "stride_distance_km": round(sum(item.distance_km for item in faster), 3),
        "reason": "Short separately recorded strides provide neuromuscular practice, not race-distance workout evidence.",
    }


def _continuous_split_pattern(
    raw_splits: str | None,
) -> tuple[bool, dict[str, Any]]:
    """
    Distinguish ordinary auto-laps from deliberate workout structure.

    Repeated distances alone never prove repetitions. A run is considered
    structured only when there is credible interruption evidence such as:
    - recorded recovery laps;
    - lap/stop/start boundaries between work segments;
    - clear alternating effort and recovery pace;
    - explicit workout wording handled by classify_session().
    """
    splits = parse_splits(raw_splits)

    if len(splits) < 2:
        return True, {
            "split_count": len(splits),
            "reason": "Too few splits to show deliberate interruption.",
        }

    boundaries = [
        split for split in splits if is_boundary_fragment(split)
    ]
    meaningful = [
        split for split in splits if not is_boundary_fragment(split)
    ]

    substantial = [
        split
        for split in meaningful
        if split.duration_s >= 120
        and split.distance_km >= 0.70
        and split.pace_s_per_km is not None
    ]

    # Auto-lap protection:
    # A sequence of broadly equal mile/km laps with no short connectors is
    # a continuous run, even if normal pace variation confuses the workout
    # recogniser.
    if len(substantial) >= 3:
        distances = [split.distance_km for split in substantial]
        average_distance = sum(distances) / len(distances)
        maximum_distance_error = max(
            abs(distance - average_distance)
            for distance in distances
        )

        distance_variation = (
            maximum_distance_error / average_distance
            if average_distance > 0
            else 1.0
        )

        short_connectors = [
            split
            for split in meaningful
            if split not in substantial
            and split.duration_s < 120
            and split.distance_km < 0.35
        ]

        substantial_share = len(substantial) / max(len(meaningful), 1)

        if (
            distance_variation <= 0.10
            and substantial_share >= 0.70
            and not short_connectors
            and not boundaries
        ):
            return True, {
                "split_count": len(splits),
                "substantial_split_count": len(substantial),
                "average_lap_distance_km": round(average_distance, 3),
                "distance_variation": round(distance_variation, 4),
                "reason": (
                    "Repeated similar auto-laps had no recovery, connector "
                    "or stop/start evidence."
                ),
            }

    recognition = recognise_workout(splits)

    if recognition.recovery_splits:
        return False, {
            "split_count": len(splits),
            "boundary_count": len(boundaries),
            "recovery_count": len(recognition.recovery_splits),
            "unknown_recovery_count":
                recognition.unknown_recovery_count,
            "recognition": recognition.description,
            "reason": "Recorded recovery segments were detected.",
        }

    if recognition.unknown_recovery_count > 0:
        return False, {
            "split_count": len(splits),
            "boundary_count": len(boundaries),
            "unknown_recovery_count":
                recognition.unknown_recovery_count,
            "recognition": recognition.description,
            "reason": (
                "Stop/start boundary evidence was detected between "
                "meaningful work segments."
            ),
        }

    if recognition.workout_type in (
        "No split data",
        "Unclassified",
        "Continuous sustained effort",
    ):
        return True, {
            "split_count": len(splits),
            "boundary_count": len(boundaries),
            "recognition": recognition.description,
            "reason": "No deliberate recovery pattern was detected.",
        }

    # A recognised repeating pattern without recovery evidence is still
    # treated as continuous. This prevents mile auto-laps becoming reps.
    return True, {
        "split_count": len(splits),
        "boundary_count": len(boundaries),
        "recognition": recognition.description,
        "reason": (
            "Repeated segments were present, but no deliberate recovery "
            "or interruption evidence supported a structured workout."
        ),
    }


def _score_continuous(
    *,
    title: str,
    continuous_pattern: bool,
    split_details: dict[str, Any],
    moving_time_s: float | None,
    elapsed_time_s: float | None,
) -> tuple[float, list[str]]:
    score = 45.0
    reasons = []

    if continuous_pattern:
        score += 35.0
        reasons.append("No deliberate recovery pattern was detected.")

    if split_details.get("substantial_split_count", 0) >= 3:
        score += 12.0
        reasons.append("Repeated substantial laps resemble auto-laps.")

    if moving_time_s and elapsed_time_s and elapsed_time_s > 0:
        ratio = max(0.0, min(moving_time_s / elapsed_time_s, 1.0))
        if ratio >= 0.985:
            score += 8.0
            reasons.append(f"Moving ratio was {ratio:.1%}.")
        elif ratio < 0.94:
            score -= 8.0

    title_intent = parse_workout_title(title)
    if _contains_any(title, WORKOUT_WORDS):
        score -= 22.0
        reasons.append("Workout wording reduced continuous-run confidence.")

    if title_intent is not None:
        score -= 18.0
        reasons.append(
            "The title describes explicit repetition structure."
        )

    return max(0.0, min(score, 100.0)), reasons


def _score_structured(
    *,
    title: str,
    continuous_pattern: bool,
    split_details: dict[str, Any],
    raw_splits: str | None,
) -> tuple[float, list[str]]:
    score = 15.0
    reasons = []

    title_intent = parse_workout_title(title)
    has_workout_wording = _contains_any(title, WORKOUT_WORDS)

    if has_workout_wording:
        score += 42.0
        reasons.append("Title contains explicit workout language.")

    if title_intent is not None:
        score += 20.0
        reasons.append(
            f"Title describes {title_intent.total_reps} planned repetition(s)."
        )

    recovery_count = split_details.get("recovery_count", 0) or 0
    unknown_recovery_count = (
        split_details.get("unknown_recovery_count", 0) or 0
    )
    boundary_count = split_details.get("boundary_count", 0) or 0

    if recovery_count:
        score += min(recovery_count * 8.0, 32.0)
        reasons.append(
            f"{recovery_count} recorded recovery segment(s) detected."
        )

    if unknown_recovery_count:
        score += min(unknown_recovery_count * 7.0, 28.0)
        reasons.append(
            f"{unknown_recovery_count} likely stopped-watch recovery gap(s)."
        )

    if boundary_count:
        score += min(boundary_count * 2.5, 15.0)
        reasons.append(
            f"{boundary_count} lap/stop/start boundary fragment(s) detected."
        )

    splits = parse_splits(raw_splits)
    recognition = recognise_workout(splits)

    if recognition.rep_count >= 3:
        score += min(recognition.rep_count * 2.0, 18.0)
        reasons.append(
            f"{recognition.rep_count} faster work segment(s) were recognised."
        )

    if recognition.workout_type == "Mixed interval session":
        score += 12.0
        reasons.append("A mixed-distance work pattern was recognised.")
    elif recognition.workout_type not in (
        "No split data",
        "Unclassified",
        "Continuous sustained effort",
    ):
        score += 7.0
        reasons.append(
            f"Split decoder recognised {recognition.workout_type.lower()}."
        )

    if continuous_pattern and not has_workout_wording and title_intent is None:
        score -= 20.0
        reasons.append(
            "No clear interruption evidence reduced workout confidence."
        )

    return max(0.0, min(score, 100.0)), reasons


def _score_race(
    facts: ActivityFacts,
    raw: dict[str, Any],
) -> tuple[float, list[str], Any]:
    race_signals = score_race_evidence(
        title=facts.title,
        distance_km=facts.distance_km,
        moving_time_s=facts.moving_time_s,
        elapsed_time_s=facts.elapsed_time_s,
        avg_hr=facts.avg_hr,
        max_hr=facts.max_hr,
        athlete_lt2_hr=facts.athlete_lt2_hr,
        athlete_max_hr=facts.athlete_max_hr,
        official_race_name=raw.get("race_name"),
        official_distance_m=raw.get("race_officialDistance"),
        official_time_s=raw.get("race_officialTime"),
        officially_measured=bool(raw.get("race_officiallyMeasured")),
    )
    return (
        max(0.0, min(race_signals.total, 100.0)),
        list(race_signals.reasons),
        race_signals,
    )


def classify_session(facts: ActivityFacts) -> Session:
    evidence: list[SessionEvidence] = []
    routes = [
        CoachRoute.ENVIRONMENT,
        CoachRoute.RECOVERY,
        CoachRoute.PROGRESS,
    ]

    sport_id = str(facts.sport_id or "")
    sport_roles = get_athlete_sport_roles(facts.athlete_id)
    sport_role = sport_roles.get(sport_id)

    if sport_role == "walking":
        return Session(
            activity_id=facts.activity_id,
            athlete_id=facts.athlete_id,
            activity_date=facts.activity_date,
            title=facts.title,
            sport_id=facts.sport_id,
            session_type=SessionType.WALK,
            purpose=SessionPurpose.GENERAL,
            confidence=1.0,
            distance_km=facts.distance_km,
            moving_time_s=facts.moving_time_s,
            elapsed_time_s=facts.elapsed_time_s,
            suitable_coaches=tuple(routes),
            metadata={
                "classification_scores": {
                    "walk": 100.0,
                    "continuous_run": 0.0,
                    "structured_workout": 0.0,
                    "race": 0.0,
                }
            },
        )

    if sport_role != "running":
        return Session(
            activity_id=facts.activity_id,
            athlete_id=facts.athlete_id,
            activity_date=facts.activity_date,
            title=facts.title,
            sport_id=facts.sport_id,
            session_type=SessionType.CROSS_TRAINING,
            purpose=SessionPurpose.GENERAL,
            confidence=0.98,
            distance_km=facts.distance_km,
            moving_time_s=facts.moving_time_s,
            elapsed_time_s=facts.elapsed_time_s,
            suitable_coaches=tuple(routes),
            metadata={
                "classification_scores": {
                    "cross_training": 98.0,
                    "continuous_run": 0.0,
                    "structured_workout": 0.0,
                    "race": 0.0,
                }
            },
        )

    raw = {}
    if facts.raw_json_text:
        try:
            raw = json.loads(facts.raw_json_text)
        except (TypeError, json.JSONDecodeError):
            raw = {}

    raw_splits = _extract_raw_splits(facts.raw_json_text)
    verified_patterns = analyse_session_patterns(facts)
    standalone_details = _standalone_strides(facts, raw_splits)
    stride_details = _easy_run_with_strides(facts, raw_splits)
    if standalone_details is not None:
        stride_details = standalone_details
    if stride_details is not None:
        continuous_pattern, split_details = True, stride_details
    else:
        continuous_pattern, split_details = _continuous_split_pattern(
            raw_splits
        )

    continuous_score, continuous_reasons = _score_continuous(
        title=facts.title,
        continuous_pattern=continuous_pattern,
        split_details=split_details,
        moving_time_s=facts.moving_time_s,
        elapsed_time_s=facts.elapsed_time_s,
    )
    workout_score, workout_reasons = _score_structured(
        title=facts.title,
        continuous_pattern=continuous_pattern,
        split_details=split_details,
        raw_splits=raw_splits,
    )
    race_score, race_reasons, race_signals = _score_race(facts, raw)

    if stride_details is not None:
        continuous_score = max(continuous_score, 92.0)
        workout_score = min(workout_score, 35.0)
        continuous_reasons.append(
            f"{stride_details['stride_count']} short finishing strides were "
            "separated from the preceding easy auto-laps."
        )
        workout_reasons.append(
            "Finishing strides cannot promote easy auto-laps into work reps."
        )
    elif (
        race_signals.classification == "confirmed_race"
        and race_signals.training_penalty == 0.0
        and race_signals.total >= 75.0
        and workout_score < continuous_score
        and (
            _contains_any(facts.title, RACE_WORDS)
            or raw.get("race_officialDistance")
            or raw.get("race_officialTime")
            or (
                facts.avg_hr is not None
                and facts.athlete_lt2_hr is not None
                and facts.avg_hr >= facts.athlete_lt2_hr
            )
        )
    ):
        race_score = max(race_score, continuous_score + 3.0)
        race_reasons.append(
            "A confirmed race takes priority over ordinary continuous auto-laps."
        )

    preliminary_scores = {
        "continuous_run": continuous_score,
        "structured_workout": workout_score,
        "race": race_score,
    }
    preliminary_order = sorted(
        preliminary_scores.items(), key=lambda item: item[1], reverse=True
    )
    preliminary_winner, preliminary_winner_score = preliminary_order[0]
    preliminary_margin = preliminary_winner_score - preliminary_order[1][1]
    preliminary_confidence = max(
        0.35,
        min(
            (preliminary_winner_score / 100.0) * 0.75
            + min(preliminary_margin / 40.0, 1.0) * 0.25,
            0.98,
        ),
    )
    # Session-pattern evidence improves workout-versus-continuous decisions;
    # it must never demote an activity the existing race evidence has already
    # selected, including older races without a fully confirmed metadata set.
    protected_race = preliminary_winner == "race"
    verified_intent = None

    if stride_details is None and not protected_race:
        if verified_patterns.pickup_count >= 5:
            verified_intent = "easy_with_pickups"
            continuous_score = max(continuous_score, 94.0)
            workout_score = min(workout_score, 35.0)
            continuous_reasons.append(
                f"{verified_patterns.pickup_count} short pickups were embedded "
                "within a substantially longer easy run."
            )
            workout_reasons.append(
                "Short pickups do not establish a prediction-quality workout."
            )
        elif verified_patterns.trustworthy_intervals:
            if (
                verified_patterns.equal_distance_alternation_count >= 3
                or verified_patterns.long_recovery_alternation_count >= 3
            ):
                verified_intent = "alternating_workout"
            if (
                preliminary_winner != "structured_workout"
                or preliminary_confidence < RELIABLE_SESSION_CONFIDENCE
            ):
                workout_score = max(
                    workout_score,
                    min(88.0 + verified_patterns.credible_recovery_count, 96.0),
                )
                continuous_score = min(continuous_score, 62.0)
                if verified_patterns.boundary_block_count >= 3:
                    pattern_reason = (
                        f"{verified_patterns.boundary_block_count} sustained "
                        "work blocks were separated by stopped-watch boundaries."
                    )
                elif verified_patterns.equal_distance_alternation_count >= 3:
                    pattern_reason = (
                        f"{verified_patterns.equal_distance_alternation_count} "
                        "faster repetitions alternated with equal-distance floats."
                    )
                elif verified_patterns.long_recovery_alternation_count >= 3:
                    pattern_reason = (
                        f"{verified_patterns.long_recovery_alternation_count} "
                        "faster efforts alternated with longer easy recoveries."
                    )
                elif verified_patterns.stopped_watch_work_count >= 4:
                    pattern_reason = (
                        f"{verified_patterns.stopped_watch_work_count} "
                        "repetitions were supported by stopped-watch recovery gaps."
                    )
                else:
                    pattern_reason = (
                        f"{verified_patterns.work_count} work repetitions and "
                        f"{verified_patterns.credible_recovery_count} slower "
                        "recoveries establish a genuine workout."
                    )
                workout_reasons.append(pattern_reason)
                continuous_reasons.append(
                    "Verified work/recovery evidence outweighs whole-run averages."
                )
        elif (
            verified_patterns.repeated_auto_laps
            and preliminary_winner == "structured_workout"
            and preliminary_confidence < RELIABLE_SESSION_CONFIDENCE
            and parse_workout_title(facts.title or "") is None
        ):
            continuous_score = max(continuous_score, 90.0)
            workout_score = min(workout_score, 48.0)
            continuous_reasons.append(
                "Similar automatic laps lack credible work/recovery alternation."
            )
            workout_reasons.append(
                "Ordinary kilometre or mile auto-laps cannot establish intervals."
            )

    scores = {
        "continuous_run": round(continuous_score, 1),
        "structured_workout": round(workout_score, 1),
        "race": round(race_score, 1),
    }

    manual_override = get_activity_overrides(facts.athlete_id).get(
        facts.activity_id, {}
    )
    manual_intent = manual_override.get("session_intent")
    manual_winners = {
        "easy": "continuous_run",
        "easy_with_strides": "continuous_run",
        "easy_with_pickups": "continuous_run",
        "long_run": "continuous_run",
        "workout": "structured_workout",
        "threshold": "structured_workout",
        "race": "race",
    }
    if manual_intent in manual_winners:
        scores[manual_winners[manual_intent]] = 100.0
        for key in scores:
            if key != manual_winners[manual_intent]:
                scores[key] = min(scores[key], 60.0)

    ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    winner, winner_score = ordered[0]
    runner_up, runner_up_score = ordered[1]
    margin = winner_score - runner_up_score

    reasons_by_type = {
        "continuous_run": continuous_reasons,
        "structured_workout": workout_reasons,
        "race": race_reasons,
    }

    confidence = max(
        0.35,
        min((winner_score / 100.0) * 0.75 + min(margin / 40.0, 1.0) * 0.25, 0.98),
    )

    metadata = {
        "split_classification": split_details,
        "classification_scores": scores,
        "classification_reasons": reasons_by_type,
        "winner": winner,
        "runner_up": runner_up,
        "score_margin": round(margin, 1),
        "verified_session_evidence": {
            "trustworthy_intervals": verified_patterns.trustworthy_intervals,
            "repeated_auto_laps": verified_patterns.repeated_auto_laps,
            "credible_recovery_count": verified_patterns.credible_recovery_count,
            "pickup_count": verified_patterns.pickup_count,
            "boundary_block_count": verified_patterns.boundary_block_count,
            "boundary_block_distance_km": verified_patterns.boundary_block_distance_km,
            "stopped_watch_work_count": verified_patterns.stopped_watch_work_count,
            "equal_distance_alternation_count": (
                verified_patterns.equal_distance_alternation_count
            ),
            "long_recovery_alternation_count": (
                verified_patterns.long_recovery_alternation_count
            ),
        },
    }
    if stride_details is not None:
        metadata["activity_intent"] = (
            "standalone_strides" if standalone_details is not None
            else "easy_with_strides"
        )
        metadata["stride_details"] = stride_details
    elif verified_intent is not None:
        metadata["activity_intent"] = verified_intent
    if manual_intent in manual_winners:
        metadata["manual_override"] = manual_intent
        if manual_intent in {
            "easy", "easy_with_strides", "easy_with_pickups", "long_run"
        }:
            metadata["activity_intent"] = manual_intent
        else:
            # Explicit coaching decisions must not inherit an automatic
            # easy/pickup intent that would hide the activity downstream.
            metadata.pop("activity_intent", None)

    if winner == "race":
        routes.extend([CoachRoute.RACE, CoachRoute.GOAL])
        session_type = SessionType.RACE
        purpose = SessionPurpose.RACE
    elif winner == "structured_workout":
        routes.extend([CoachRoute.WORKOUT, CoachRoute.THRESHOLD])
        session_type = SessionType.STRUCTURED_WORKOUT
        if _contains_any(
            facts.title,
            ("threshold", "tempo", "cruise"),
        ):
            purpose = SessionPurpose.THRESHOLD
        elif (
            _contains_any(facts.title, ("fartlek",))
            or verified_intent == "alternating_workout"
        ):
            purpose = SessionPurpose.FARTLEK
        elif _contains_any(facts.title, ("hill rep", "hill session")):
            purpose = SessionPurpose.HILLS
        elif _contains_any(
            facts.title,
            ("vo2", "5k pace", "3k pace"),
        ):
            purpose = SessionPurpose.VO2
        else:
            purpose = SessionPurpose.UNKNOWN
    else:
        routes.append(CoachRoute.EASY)
        session_type = SessionType.CONTINUOUS_RUN
        purpose = (
            SessionPurpose.EASY
            if stride_details is not None or verified_intent == "easy_with_pickups"
            else SessionPurpose.GENERAL
        )

    evidence.append(
        SessionEvidence(
            key="explainable_classification",
            description=(
                f"{winner.replace('_', ' ').title()} scored "
                f"{winner_score:.1f}; {runner_up.replace('_', ' ').title()} "
                f"scored {runner_up_score:.1f}."
            ),
            strength=confidence,
            supports=winner,
            metadata=metadata,
        )
    )

    return Session(
        activity_id=facts.activity_id,
        athlete_id=facts.athlete_id,
        activity_date=facts.activity_date,
        title=facts.title,
        sport_id=facts.sport_id,
        session_type=session_type,
        purpose=purpose,
        confidence=confidence,
        distance_km=facts.distance_km,
        moving_time_s=facts.moving_time_s,
        elapsed_time_s=facts.elapsed_time_s,
        avg_hr=facts.avg_hr,
        max_hr=facts.max_hr,
        elevation_up_m=facts.elevation_up_m,
        temperature_c=facts.temperature_c,
        humidity=facts.humidity,
        wind_speed=facts.wind_speed,
        route_name=facts.route_name,
        evidence=tuple(evidence),
        suitable_coaches=tuple(dict.fromkeys(routes)),
        metadata=metadata,
    )
